// ============================================================
// GESTÃO DE DEMANDAS DE TI
// V2.5 — DETALHE DA DEMANDA — PRIORIDADE DE ATENDIMENTO EDITÁVEL
// ============================================================
// ARQUIVO: src/pages/DetalheDemanda.tsx
//
// FUNCIONALIDADES:
// - Visualização completa da demanda
// - Alteração de status
// - Com Pendências com motivo obrigatório
// - Conclusão com comentário obrigatório
// - Distribuição / redistribuição para Responsável
// - Alteração de prioridade
// - Alteração manual de prazo
// - Reabertura com motivo obrigatório
// - Cancelamento com motivo obrigatório
// - Comentários
// - Anexos
// - Histórico
// - Validação de arquivos
// - Compatibilidade com a estrutura atual da V2.3
// ============================================================
import {
  useEffect,
  useState,
  type ChangeEvent,
} from 'react'
import { ehPerfilOperacional } from '../types'
import type {
  Demanda,
  Comentario,
  Arquivo,
  Historico,
  Usuario,
} from '../types'
import MenuPrincipal from '../components/MenuPrincipal'
import './DetalheDemanda.css'
import { mostrarToast } from '../services/toast'
import { PRIORIDADES_ATENDIMENTO } from '../sla'
// ============================================================
// PROPS
// ============================================================
type Props = {
  demanda: Demanda
  onVoltar: () => void
  nomeUsuario: string
  perfilUsuarioGlobal: string
  onDashboard: () => void
  onMinhasDemandas?: () => void
  onTodasDemandas: () => void
  onNovaDemanda: () => void
  onClientes: () => void
  onResponsaveis: () => void
  onFeriados: () => void
  onRelatorios: () => void
  onConfiguracoes?: () => void
  onLogout: () => void
  onAlterarStatus: (
    id: number,
    novoStatus: string,
    motivo?: string
  ) => void
  onAlterarResponsavel?: (
    id: number,
    novoResponsavel: string
  ) => void
  onAdicionarComentario?: (
    id: number,
    texto: string
  ) => void
  onAdicionarArquivo?: (
    id: number,
    arquivo: Arquivo
  ) => void
  perfilUsuario?: Usuario['perfil']
  analistas?: Usuario[]
  onAlterarPrioridade?: (
    id: number,
    novaPrioridade: string,
    motivo?: string
  ) => boolean | void
  onAlterarPrioridadeAtendimento?: (
    id: number,
    novaPrioridadeAtendimento: string,
    motivo?: string
  ) => boolean | void
  onAlterarPrazoManual?: (
    id: number,
    novoPrazo: string,
    motivo: string
  ) => void
  onReabrirDemanda?: (
    id: number,
    motivo: string
  ) => void
  onCancelarDemanda?: (
    id: number,
    motivo: string
  ) => void
}
// ============================================================
// STATUS
// ============================================================
const STATUS = [
  'Nova',
  'Aguardando',
  'Em Atendimento',
  'Com Pendências',
  'Concluída',
]
// ============================================================
// CRITICIDADES
// ============================================================
const PRIORIDADES = [
  'Crítica',
  'Alta',
  'Média',
  'Baixa',
]
// ============================================================
// FORMATAÇÕES
// ============================================================
function formatarData(data: string) {
  if (!data) {
    return '-'
  }
  const partes = data.split('-')
  if (partes.length === 3) {
    return `${partes[2]}/${partes[1]}/${partes[0]}`
  }
  return data
}
// ============================================================
function formatarDataHora(data: string) {
  const objeto = new Date(data)
  if (Number.isNaN(objeto.getTime())) {
    return data
  }
  return objeto.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}
// ============================================================
function formatarTamanho(bytes: number) {
  if (bytes < 1024) {
    return `${bytes} B`
  }
  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
// ============================================================
// CLASSE STATUS
// ============================================================
function classeStatus(status: string) {
  switch (status) {
    case 'Nova':
      return 'status-nova'
    case 'Aguardando':
      return 'status-nova'
    case 'Em Atendimento':
      return 'status-em-atendimento'
    case 'Com Pendências':
      return 'status-com-pendencias'
    case 'Concluída':
      return 'status-concluida'
    case 'Cancelada':
      return 'status-cancelada'
    default:
      return 'status-nova'
  }
}
// ============================================================
// CLASSE CRITICIDADE
// ============================================================
function classePrioridade(
  prioridade: string
) {
  switch (prioridade) {
    case 'Crítica':
    case 'Urgente':
      return 'prioridade-alta'
    case 'Alta':
      return 'prioridade-alta'
    case 'Média':
      return 'prioridade-media'
    default:
      return 'prioridade-baixa'
  }
}
// ============================================================
// CLASSE DA PRIORIDADE DE ATENDIMENTO
// P1 vermelho escuro | P2 vermelho | P3 azul | P4 verde
// ============================================================
function classePrioridadeAtendimento(prioridade: string) {
  const valor = prioridade.trim().toLocaleUpperCase('pt-BR')
  if (valor.startsWith('P1') || valor.includes('IMEDIATA')) {
    return 'prioridade-atendimento-p1'
  }
  if (valor.startsWith('P2') || valor.includes('URGENTE')) {
    return 'prioridade-atendimento-p2'
  }
  if (valor.startsWith('P3') || valor.includes('NORMAL')) {
    return 'prioridade-atendimento-p3'
  }
  if (valor.startsWith('P4') || valor.includes('PLANEJADA')) {
    return 'prioridade-atendimento-p4'
  }
  return ''
}
// ============================================================
// COMPONENTE
// ============================================================
export function DetalheDemandaPage({
  demanda,
  onVoltar,
  nomeUsuario,
  perfilUsuarioGlobal,
  onDashboard,
  onMinhasDemandas,
  onTodasDemandas,
  onNovaDemanda,
  onClientes,
  onResponsaveis,
  onFeriados,
  onRelatorios,
  onConfiguracoes,
  onLogout,
  onAlterarStatus,
  onAlterarResponsavel,
  onAdicionarComentario,
  onAdicionarArquivo,
  perfilUsuario,
  analistas = [],
  onAlterarPrioridade,
  onAlterarPrioridadeAtendimento,
  onAlterarPrazoManual,
  onReabrirDemanda,
  onCancelarDemanda,
}: Props) {
  // ==========================================================
  // STATUS
  // ==========================================================
  const [
    statusSelecionado,
    setStatusSelecionado,
  ] = useState(
    demanda.status
  )
  // ==========================================================
  // ANALISTA
  // ==========================================================
  const [
    responsavelSelecionado,
    setResponsavelSelecionado,
  ] = useState(
    demanda.responsavel || ''
  )
  // ==========================================================
  // COMENTÁRIO
  // ==========================================================
  const [
    comentario,
    setComentario,
  ] = useState('')
  // ==========================================================
  // COMENTÁRIOS LOCAIS
  // ==========================================================
  const [
    comentariosLocais,
    setComentariosLocais,
  ] = useState<Comentario[]>(
    demanda.comentarios || []
  )
  // ==========================================================
  // ARQUIVOS
  // ==========================================================
  const [
    arquivosLocais,
    setArquivosLocais,
  ] = useState<Arquivo[]>(
    demanda.arquivos || []
  )
  // ==========================================================
  // HISTÓRICO
  // ==========================================================
  const [
    historicoLocal,
    setHistoricoLocal,
  ] = useState<Historico[]>(
    demanda.historico || []
  )
  // ==========================================================
  // COMENTÁRIOS PENDENTES
  // ==========================================================
  const [
    comentariosPendentes,
    setComentariosPendentes,
  ] = useState<number[]>([])
  // ==========================================================
  // ARQUIVOS PENDENTES
  // ==========================================================
  const [
    arquivosPendentes,
    setArquivosPendentes,
  ] = useState<number[]>([])
  // ==========================================================
  // SALVANDO
  // ==========================================================
  const [
    salvando,
    setSalvando,
  ] = useState(false)
  // ==========================================================
  // PENDÊNCIA
  // ==========================================================
  const [
    mostrarPendencia,
    setMostrarPendencia,
  ] = useState(false)
  const [
    motivoPendencia,
    setMotivoPendencia,
  ] = useState('')
  // ==========================================================
  // CONCLUSÃO
  // ==========================================================
  const [
    mostrarConclusao,
    setMostrarConclusao,
  ] = useState(false)
  const [
    comentarioConclusao,
    setComentarioConclusao,
  ] = useState('')
  // ==========================================================
  // CRITICIDADE
  // ==========================================================
  const [
    prioridadeSelecionada,
    setPrioridadeSelecionada,
  ] = useState(''
)
  // PRIORIDADE DE ATENDIMENTO
  const [prioridadeAtendimentoSelecionada, setPrioridadeAtendimentoSelecionada] = useState('')
  // ==========================================================
  // PRAZO
  // ==========================================================
  const [
    novoPrazo,
    setNovoPrazo,
  ] = useState(
    demanda.prazo || ''
  )
  // ==========================================================
  // MOTIVO ALTERAÇÃO
  // ==========================================================
  const [
    motivoAlteracao,
    setMotivoAlteracao,
  ] = useState('')
  // ==========================================================
  // MOTIVO REABERTURA
  // ==========================================================
  const [
    motivoReabertura,
    setMotivoReabertura,
  ] = useState('')
  // ==========================================================
  // MOTIVO CANCELAMENTO
  // ==========================================================
  const [
    motivoCancelamento,
    setMotivoCancelamento,
  ] = useState('')
  // ==========================================================
  // EXIBIR CANCELAMENTO
  // ==========================================================
  const [
    mostrarCancelamento,
    setMostrarCancelamento,
  ] = useState(false)
  // ==========================================================
  // SINCRONIZAR COM A DEMANDA
  // ==========================================================
  useEffect(() => {
    setStatusSelecionado(
      demanda.status
    )
    setPrioridadeSelecionada('')
    setPrioridadeAtendimentoSelecionada('')
    setNovoPrazo(
      demanda.prazo || ''
    )
    setMotivoAlteracao('')
    setMotivoReabertura('')
    setMotivoCancelamento('')
    setMostrarCancelamento(
      false
    )
    setResponsavelSelecionado(
      demanda.responsavel || ''
    )
    setComentariosLocais(
      demanda.comentarios || []
    )
    setArquivosLocais(
      demanda.arquivos || []
    )
    setHistoricoLocal(
      demanda.historico || []
    )
    setComentariosPendentes([])
    setArquivosPendentes([])
    setComentario('')
    setMostrarPendencia(false)
    setMotivoPendencia('')
    setMostrarConclusao(false)
    setComentarioConclusao('')
  }, [demanda])
  // ==========================================================
  // ADICIONAR COMENTÁRIO LOCAL
  // ==========================================================
  function adicionarComentarioLocal() {
    const texto =
      comentario.trim()
    if (!texto) {
      return
    }
    const id =
      Date.now()
    const data =
      new Date().toISOString()
    const novoComentario:
      Comentario = {
      id,
      texto,
      usuario:
        nomeUsuario,
      data,
    }
    const novoHistorico:
      Historico = {
      id:
        id + 1,
      tipo:
        'comentario',
      titulo:
        'Comentário adicionado',
      descricao:
        texto,
      data,
      usuario:
        nomeUsuario,
      referenciaId:
        id,
    }
    setComentariosLocais(
      (atual) => [
        ...atual,
        novoComentario,
      ]
    )
    setComentariosPendentes(
      (atual) => [
        ...atual,
        id,
      ]
    )
    setHistoricoLocal(
      (atual) => [
        novoHistorico,
        ...atual,
      ]
    )
    setComentario('')
  }
  // ==========================================================
  // EXCLUIR COMENTÁRIO PENDENTE
  // ==========================================================
  function excluirComentario(
    id: number
  ) {
    if (
      !comentariosPendentes.includes(
        id
      )
    ) {
      return
    }
    setComentariosLocais(
      (atual) =>
        atual.filter(
          (item) =>
            item.id !== id
        )
    )
    setComentariosPendentes(
      (atual) =>
        atual.filter(
          (item) =>
            item !== id
        )
    )
    setHistoricoLocal(
      (atual) =>
        atual.filter(
          (item) =>
            item.referenciaId !==
            id
        )
    )
  }
  // ==========================================================
  // SELECIONAR ARQUIVO
  // ==========================================================
  function selecionarArquivo(
    event: ChangeEvent<HTMLInputElement>
  ) {
    const arquivo =
      event.target.files?.[0]
    if (!arquivo) {
      return
    }
    // --------------------------------------------------------
    // LIMITE 20 MB
    // --------------------------------------------------------
    if (
      arquivo.size >
      20 * 1024 * 1024
    ) {
      alert(
        'O arquivo não pode ultrapassar 20 MB.'
      )
      event.target.value =
        ''
      return
    }
    // --------------------------------------------------------
    // EXTENSÃO
    // --------------------------------------------------------
    const extensao =
      arquivo.name
        .split('.')
        .pop()
        ?.toLowerCase()
    const permitidos = [
      'pdf',
      'doc',
      'docx',
      'xls',
      'xlsx',
      'csv',
      'txt',
      'png',
      'jpg',
      'jpeg',
    ]
    if (
      !extensao ||
      !permitidos.includes(
        extensao
      )
    ) {
      alert(
        'Formato de arquivo não permitido.'
      )
      event.target.value =
        ''
      return
    }
    // --------------------------------------------------------
    // LEITURA
    // --------------------------------------------------------
    const leitor =
      new FileReader()
    leitor.onload = () => {
      const id =
        Date.now()
      const data =
        new Date().toISOString()
      const novoArquivo:
        Arquivo = {
        id,
        nome:
          arquivo.name,
        tamanho:
          arquivo.size,
        data,
        usuario:
          nomeUsuario,
        url:
          typeof leitor.result ===
          'string'
            ? leitor.result
            : '',
      }
      const novoHistorico:
        Historico = {
        id:
          id + 1,
        tipo:
          'arquivo',
        titulo:
          'Arquivo anexado',
        descricao:
          `O arquivo "${arquivo.name}" foi anexado à demanda.`,
        data,
        usuario:
          nomeUsuario,
        referenciaId:
          id,
      }
      setArquivosLocais(
        (atual) => [
          ...atual,
          novoArquivo,
        ]
      )
      setArquivosPendentes(
        (atual) => [
          ...atual,
          id,
        ]
      )
      setHistoricoLocal(
        (atual) => [
          novoHistorico,
          ...atual,
        ]
      )
    }
    leitor.readAsDataURL(
      arquivo
    )
    event.target.value =
      ''
  }
  // ==========================================================
  // EXCLUIR ARQUIVO PENDENTE
  // ==========================================================
  function excluirArquivo(
    id: number
  ) {
    if (
      !arquivosPendentes.includes(
        id
      )
    ) {
      return
    }
    setArquivosLocais(
      (atual) =>
        atual.filter(
          (arquivo) =>
            arquivo.id !== id
        )
    )
    setArquivosPendentes(
      (atual) =>
        atual.filter(
          (item) =>
            item !== id
        )
    )
    setHistoricoLocal(
      (atual) =>
        atual.filter(
          (item) =>
            item.referenciaId !==
            id
        )
    )
  }
  // ==========================================================
  // BAIXAR ARQUIVO
  // ==========================================================
  function baixarArquivo(
    arquivo: Arquivo
  ) {
    if (!arquivo.url) {
      return
    }
    const link =
      document.createElement(
        'a'
      )
    link.href =
      arquivo.url
    link.download =
      arquivo.nome
    document.body.appendChild(
      link
    )
    link.click()
    document.body.removeChild(
      link
    )
  }
  // ==========================================================
  // SELECIONAR STATUS
  // ==========================================================
  function selecionarStatus(
    novoStatus: string
  ) {
    if (
      novoStatus ===
      statusSelecionado
    ) {
      return
    }
    // --------------------------------------------------------
    // PENDÊNCIA
    // --------------------------------------------------------
    if (
      novoStatus ===
      'Com Pendências'
    ) {
      // Atualiza imediatamente o combo para refletir a escolha.
      // A confirmação definitiva continua em Salvar Alterações.
      setStatusSelecionado(
        'Com Pendências'
      )
      setComentarioConclusao(
        ''
      )
      setMostrarConclusao(
        false
      )
      setMotivoPendencia(
        ''
      )
      setMostrarPendencia(
        true
      )
      return
    }
    // --------------------------------------------------------
    // CONCLUSÃO
    // --------------------------------------------------------
    if (
      novoStatus ===
      'Concluída'
    ) {
      // Atualiza imediatamente o combo para refletir a escolha.
      // A confirmação definitiva continua em Salvar Alterações.
      setStatusSelecionado(
        'Concluída'
      )
      setMotivoPendencia(
        ''
      )
      setMostrarPendencia(
        false
      )
      setComentarioConclusao(
        ''
      )
      setMostrarConclusao(
        true
      )
      return
    }
    // --------------------------------------------------------
    // ATENDIMENTO / DEMAIS STATUS
    // --------------------------------------------------------
    if (
      novoStatus ===
        'Em Atendimento' &&
      !responsavelSelecionado.trim()
    ) {
      alert(
        'A demanda precisa ter um Responsável definido para entrar em atendimento.'
      )
      return
    }
    setMostrarPendencia(
      false
    )
    setMostrarConclusao(
      false
    )
    setStatusSelecionado(
      novoStatus
    )
  }
  // CONFIRMAR PENDÊNCIA
  // ==========================================================
  function confirmarPendencia() {
    const motivo =
      motivoPendencia.trim()
    if (!motivo) {
      alert(
        'Informe obrigatoriamente o motivo da pendência.'
      )
      return
    }
    const id =
      Date.now()
    const data =
      new Date().toISOString()
    setStatusSelecionado(
      'Com Pendências'
    )
    const historicoStatus:
      Historico = {
      id,
      tipo:
        'status',
      titulo:
        'Demanda colocada em Com Pendências',
      descricao:
        'A demanda foi colocada em "Com Pendências".',
      data,
      usuario:
        nomeUsuario,
      referenciaId:
        demanda.id,
      valorAnterior:
        demanda.status,
      valorNovo:
        'Com Pendências',
      motivo,
    }
    const historicoMotivo:
      Historico = {
      id:
        id + 1,
      tipo:
        'pendencia',
      titulo:
        'Motivo da Pendência',
      descricao:
        motivo,
      data,
      usuario:
        nomeUsuario,
      referenciaId:
        demanda.id,
      motivo,
    }
    setHistoricoLocal(
      (atual) => [
        historicoMotivo,
        historicoStatus,
        ...atual,
      ]
    )
    setMostrarPendencia(
      false
    )
  }
  // ==========================================================
  // CONFIRMAR CONCLUSÃO
  // ==========================================================
  function confirmarConclusao() {
    const texto =
      comentarioConclusao.trim()
    if (!texto) {
      alert(
        'Informe obrigatoriamente um comentário para concluir a demanda.'
      )
      return
    }
    const id =
      Date.now()
    const data =
      new Date().toISOString()
    const novoComentario:
      Comentario = {
      id,
      texto,
      usuario:
        nomeUsuario,
      data,
    }
    const novoHistorico:
      Historico = {
      id:
        id + 1,
      tipo:
        'conclusao',
      titulo:
        'Demanda concluída',
      descricao:
        `A demanda foi concluída. Comentário: ${texto}`,
      data,
      usuario:
        nomeUsuario,
      referenciaId:
        id,
      valorAnterior:
        demanda.status,
      valorNovo:
        'Concluída',
      motivo:
        texto,
    }
    setStatusSelecionado(
      'Concluída'
    )
    setComentariosLocais(
      (atual) => [
        ...atual,
        novoComentario,
      ]
    )
    setComentariosPendentes(
      (atual) => [
        ...atual,
        id,
      ]
    )
    setHistoricoLocal(
      (atual) => [
        novoHistorico,
        ...atual,
      ]
    )
    setComentarioConclusao(
      ''
    )
    setMostrarConclusao(
      false
    )
  }
  // ==========================================================
  // CANCELAR PENDÊNCIA
  // ==========================================================
  function cancelarPendencia() {
    setMotivoPendencia(
      ''
    )
    setMostrarPendencia(
      false
    )
    setStatusSelecionado(
      demanda.status
    )
  }
  // ==========================================================
  // CANCELAR CONCLUSÃO
  // ==========================================================
  function cancelarConclusao() {
    setComentarioConclusao(
      ''
    )
    setMostrarConclusao(
      false
    )
    setStatusSelecionado(
      demanda.status
    )
  }
  // ==========================================================
  // CONFIRMAR CANCELAMENTO
  // ==========================================================
  function confirmarCancelamento() {
    const motivo =
      motivoCancelamento.trim()
    if (!motivo) {
      alert(
        'Informe obrigatoriamente o motivo do cancelamento.'
      )
      return
    }
    if (
      !onCancelarDemanda
    ) {
      alert(
        'A operação de cancelamento não está disponível.'
      )
      return
    }
    onCancelarDemanda(
      demanda.id,
      motivo
    )
    mostrarToast(
      'Demanda Cancelada Com Sucesso.'
    )
    setMotivoCancelamento(
      ''
    )
    setMostrarCancelamento(
      false
    )
  }
  // ==========================================================
  // ALTERAÇÕES PENDENTES
  // ==========================================================
  const alteracoesPendentes =
    statusSelecionado !==
      demanda.status ||
    responsavelSelecionado !==
      (demanda.responsavel ||
        '') ||
    comentariosPendentes.length >
      0 ||
    arquivosPendentes.length >
      0
  // ==========================================================
  // SALVAR ALTERAÇÕES
  // ==========================================================
  function salvarAlteracoes() {
    if (
      !alteracoesPendentes
    ) {
      return
    }
    setSalvando(
      true
    )
    // --------------------------------------------------------
    // STATUS
    // --------------------------------------------------------
    if (
      statusSelecionado !==
      demanda.status
    ) {
      let motivoStatus:
        string | undefined
      if (
        statusSelecionado ===
        'Com Pendências'
      ) {
        motivoStatus =
          motivoPendencia.trim()
      } else if (
        statusSelecionado ===
        'Concluída'
      ) {
        // A conclusão exige comentário obrigatório no App.
        // O comentário de conclusão foi criado como pendente
        // logo antes da mudança de status.
        const comentarioConclusaoPendente =
          comentariosLocais
            .filter((item) =>
              comentariosPendentes.includes(item.id)
            )
            .at(-1)
        motivoStatus =
          comentarioConclusaoPendente?.texto?.trim() ||
          undefined
      }
      onAlterarStatus(
        demanda.id,
        statusSelecionado,
        motivoStatus
      )
    }
    // --------------------------------------------------------
    // ANALISTA
    // --------------------------------------------------------
    if (
      responsavelSelecionado !==
        (demanda.responsavel ||
          '') &&
      onAlterarResponsavel
    ) {
      onAlterarResponsavel(
        demanda.id,
        responsavelSelecionado
      )
    }
    // --------------------------------------------------------
    // COMENTÁRIOS
    // --------------------------------------------------------
    if (
      onAdicionarComentario
    ) {
      const pendentes =
        comentariosLocais.filter(
          (item) =>
            comentariosPendentes.includes(
              item.id
            )
        )
      pendentes.forEach(
        (item) => {
          onAdicionarComentario(
            demanda.id,
            item.texto
          )
        }
      )
    }
    // --------------------------------------------------------
    // ARQUIVOS
    // --------------------------------------------------------
    if (
      onAdicionarArquivo
    ) {
      const pendentes =
        arquivosLocais.filter(
          (item) =>
            arquivosPendentes.includes(
              item.id
            )
        )
      pendentes.forEach(
        (arquivo) => {
          onAdicionarArquivo(
            demanda.id,
            arquivo
          )
        }
      )
    }
    // --------------------------------------------------------
    // LIMPAR PENDÊNCIAS
    // --------------------------------------------------------
    setComentariosPendentes(
      []
    )
    setArquivosPendentes(
      []
    )
    setSalvando(
      false
    )
    mostrarToast(
      'Alterações Da Demanda Salvas Com Sucesso.'
    )
  }
  // ==========================================================
  // RENDER
  // ==========================================================
  return (
    <>
      <MenuPrincipal
        usuarioAtual={{
          id: 0,
          nome: nomeUsuario,
          login: '',
          email: '',
          perfil:
            ehPerfilOperacional(perfilUsuarioGlobal)
              ? perfilUsuarioGlobal as Usuario['perfil']
              : 'Gestor/Administrador',
          status: 'Ativo',
          criadoEm: '',
        }}
        ativo={ehPerfilOperacional(perfilUsuarioGlobal) ? 'minhas-demandas' : 'todas-demandas'}
        onDashboard={onDashboard}
        onMinhasDemandas={onMinhasDemandas}
        onTodasDemandas={onTodasDemandas}
        onNovaDemanda={onNovaDemanda}
        onClientes={onClientes}
        onResponsaveis={onResponsaveis}
        onFeriados={onFeriados}
        onRelatorios={onRelatorios}
        onConfiguracoes={onConfiguracoes}
        onMinhaConta={ehPerfilOperacional(perfilUsuarioGlobal) ? onConfiguracoes : undefined}
        onSair={onLogout}
        subtitulo="Detalhamento e acompanhamento da demanda"
        rodapeAcoes={
          <>
            <button
              className="btn-secundario"
              type="button"
              onClick={onVoltar}
            >
              ← Voltar ao Dashboard
            </button>
            <button
              className="btn-principal"
              type="button"
              disabled={!alteracoesPendentes || salvando}
              onClick={salvarAlteracoes}
            >
              {salvando ? 'Salvando...' : '✓ Salvar Alterações'}
            </button>
          </>
        }
      >
        <div className="detalhe-page">
        <div className="detalhe-container">
        {/* ==================================================
            CABEÇALHO
            ================================================== */}
        <div className="detalhe-header">
          <div>
            <div className="detalhe-codigo">
              DEMANDA #{demanda.id}
            </div>
            <h1>
              {demanda.titulo}
            </h1>
            <p>
              Detalhamento da demanda de TI
            </p>
          </div>
          <span
            className={`status-badge ${classeStatus(
              statusSelecionado
            )}`}
          >
            {statusSelecionado}
          </span>
        </div>
        {/* ==================================================
            DADOS DA DEMANDA
            ================================================== */}
        <section className="detalhe-card">
          <div className="card-title">
            Dados da Demanda
          </div>
          <div className="dados-grid">
            <div>
              <span>
                CLIENTE / ÓRGÃO
              </span>
              <strong>
                {demanda.cliente ||
                  '-'}
              </strong>
            </div>
            <div>
              <span>
                SISTEMA
              </span>
              <strong>
                {demanda.sistema ||
                  'Não informado'}
              </strong>
            </div>
            <div>
              <span>
                TIPO DA DEMANDA
              </span>
              <strong>
                {demanda.tipo ||
                  'Não informado'}
              </strong>
            </div>
            <div>
              <span>
                RESPONSÁVEL
              </span>
              <strong>
                {responsavelSelecionado ||
                  'Não atribuído'}
              </strong>
            </div>
            <div>
              <span>CRITICIDADE</span>
              <strong className={classePrioridade(demanda.criticidade || demanda.prioridade || '')}>
                {demanda.criticidade || demanda.prioridade || 'Não definida'}
              </strong>
            </div>
            <div>
              <span>PRIORIDADE DE ATENDIMENTO</span>
              <strong className={classePrioridadeAtendimento(demanda.prioridadeAtendimento || '')}>
                {demanda.prioridadeAtendimento || 'Não definida'}
              </strong>
            </div>
            <div>
              <span>
                PRAZO
              </span>
              <strong>
                {formatarData(
                  demanda.prazo
                )}
              </strong>
            </div>
          </div>
          {/* =================================================
              CONTROLES DO GESTOR
              ================================================= */}
          {perfilUsuario ===
            'Gestor/Administrador' && (
            <div
              className="gestor-controles"
              style={{
                marginTop:
                  '18px',
                padding:
                  '16px',
                border:
                  '1px solid #dce5ef',
                borderRadius:
                  '10px',
                background:
                  '#f8fbff',
              }}
            >
              <strong
                style={{
                  display:
                    'block',
                  marginBottom:
                    '12px',
                }}
              >
                Controles do Gestor
              </strong>
              <div className="dados-grid">
                {/* CRITICIDADE */}
                <div className="campo-acao">
                  <label>
                    Criticidade
                  </label>
                  <select
                    value={
                      prioridadeSelecionada
                    }
                    onChange={(event) =>
                      setPrioridadeSelecionada(
                        event.target.value
                      )
                    }
                  >
                    <option value="">
                      Selecione...
                    </option>
                    {PRIORIDADES.map(
                      (item) => (
                        <option
                          key={item}
                          value={item}
                        >
                          {item}
                        </option>
                      )
                    )}
                  </select>
                </div>
                {/* PRIORIDADE DE ATENDIMENTO */}
                <div className="campo-acao">
                  <label htmlFor="prioridade-atendimento-gestor">
                    Prioridade de Atendimento
                  </label>
                  <select
                    id="prioridade-atendimento-gestor"
                    className={`prioridade-atendimento-select ${classePrioridadeAtendimento(prioridadeAtendimentoSelecionada)}`}
                    value={prioridadeAtendimentoSelecionada}
                    onChange={(event) => setPrioridadeAtendimentoSelecionada(event.target.value)}
                    disabled={demanda.status === 'Concluída' || demanda.status === 'Cancelada'}
                  >
                    <option value="">Selecione...</option>
                    {PRIORIDADES_ATENDIMENTO.map((item) => (
                      <option
                        key={item}
                        value={item}
                        className={classePrioridadeAtendimento(item)}
                      >
                        {item}
                      </option>
                    ))}
                  </select>
                </div>
                {/* PRAZO */}
                <div className="campo-acao">
                  <label>
                    Novo prazo
                  </label>
                  <input
                    type="date"
                    value={
                      novoPrazo
                    }
                    onChange={(event) =>
                      setNovoPrazo(
                        event.target.value
                      )
                    }
                  />
                </div>
              </div>
              {/* MOTIVO */}
              <textarea
                value={
                  motivoAlteracao
                }
                onChange={(event) =>
                  setMotivoAlteracao(
                    event.target.value
                  )
                }
                placeholder="Motivo obrigatório para alteração de prazo ou prioridade."
                style={{
                  width:
                    '100%',
                  minHeight:
                    '70px',
                  marginTop:
                    '10px',
                }}
              />
              {/* BOTÕES */}
              <div
                style={{
                  display:
                    'flex',
                  gap:
                    '10px',
                  marginTop:
                    '10px',
                  flexWrap:
                    'wrap',
                }}
              >
                <button
                  type="button"
                  className="btn-principal"
                  disabled={
                    !prioridadeSelecionada ||
                    prioridadeSelecionada ===
                    (demanda.criticidade || demanda.prioridade || '')
                  }
                  onClick={() => {
                    if (
                      !motivoAlteracao.trim()
                    ) {
                      alert(
                        'Informe o motivo da alteração de prioridade.'
                      )
                      return
                    }
                    if (!onAlterarPrioridade) {
                      alert('A alteração da Criticidade não está disponível.')
                      return
                    }
                    const alteracaoConcluida = onAlterarPrioridade(
                      demanda.id,
                      prioridadeSelecionada,
                      motivoAlteracao.trim()
                    )
                    if (alteracaoConcluida === false) {
                      return
                    }
                    mostrarToast(
                      'Criticidade Da Demanda Alterada Com Sucesso.'
                    )
                    setPrioridadeSelecionada('')
                    setMotivoAlteracao(
                      ''
                    )
                  }}
                >
                  Alterar Criticidade
                </button>
                <button
                  type="button"
                  className="btn-principal"
                  disabled={
                    !prioridadeAtendimentoSelecionada ||
                    prioridadeAtendimentoSelecionada === (demanda.prioridadeAtendimento || '') ||
                    demanda.status === 'Concluída' ||
                    demanda.status === 'Cancelada'
                  }
                  onClick={() => {
                    if (!motivoAlteracao.trim()) {
                      alert('Informe o motivo da alteração da Prioridade de Atendimento.')
                      return
                    }
                    if (!onAlterarPrioridadeAtendimento) {
                      alert('A alteração da Prioridade de Atendimento não está disponível.')
                      return
                    }
                    const alteracaoConcluida = onAlterarPrioridadeAtendimento(
                      demanda.id,
                      prioridadeAtendimentoSelecionada,
                      motivoAlteracao.trim()
                    )
                    if (alteracaoConcluida === false) {
                      return
                    }
                    mostrarToast('Prioridade de Atendimento alterada com sucesso.')
                    setPrioridadeAtendimentoSelecionada('')
                    setMotivoAlteracao('')
                  }}
                >
                  Alterar Prioridade
                </button>
                <button
                  type="button"
                  className="btn-principal"
                  onClick={() => {
                    if (
                      !novoPrazo
                    ) {
                      alert(
                        'Informe o novo prazo.'
                      )
                      return
                    }
                    if (
                      !motivoAlteracao.trim()
                    ) {
                      alert(
                        'Informe o motivo da alteração do prazo.'
                      )
                      return
                    }
                    onAlterarPrazoManual?.(
                      demanda.id,
                      novoPrazo,
                      motivoAlteracao.trim()
                    )
                    mostrarToast(
                      'Prazo Da Demanda Alterado Com Sucesso.'
                    )
                    setMotivoAlteracao(
                      ''
                    )
                  }}
                >
                  Alterar Prazo
                </button>
              </div>
              {/* =================================================
                  REABERTURA
                  ================================================= */}
              {demanda.status ===
                'Concluída' && (
                <div
                  style={{
                    marginTop:
                      '16px',
                    paddingTop:
                      '14px',
                    borderTop:
                      '1px solid #dce5ef',
                  }}
                >
                  <strong
                    style={{
                      display:
                        'block',
                      marginBottom:
                        '8px',
                    }}
                  >
                    Reabertura da Demanda
                  </strong>
                  <textarea
                    value={
                      motivoReabertura
                    }
                    onChange={(event) =>
                      setMotivoReabertura(
                        event.target.value
                      )
                    }
                    placeholder="Informe obrigatoriamente o motivo da reabertura."
                    style={{
                      width:
                        '100%',
                      minHeight:
                        '70px',
                    }}
                  />
                  <button
                    type="button"
                    className="btn-principal"
                    style={{
                      marginTop:
                        '10px',
                    }}
                    onClick={() => {
                      if (
                        !motivoReabertura.trim()
                      ) {
                        alert(
                          'Informe o motivo da reabertura.'
                        )
                        return
                      }
                      onReabrirDemanda?.(
                        demanda.id,
                        motivoReabertura.trim()
                      )
                      mostrarToast(
                        'Demanda Reaberta Com Sucesso.'
                      )
                      setMotivoReabertura(
                        ''
                      )
                    }}
                  >
                    ↻ Reabrir Demanda
                  </button>
                </div>
              )}
              {/* =================================================
                  CANCELAMENTO
                  ================================================= */}
              {demanda.status !==
                'Concluída' &&
                demanda.status !==
                  'Cancelada' && (
                <div
                  style={{
                    marginTop:
                      '16px',
                    paddingTop:
                      '14px',
                    borderTop:
                      '1px solid #dce5ef',
                  }}
                >
                  {!mostrarCancelamento ? (
                    <button
                      type="button"
                      className="btn-danger-outline"
                      onClick={() =>
                        setMostrarCancelamento(
                          true
                        )
                      }
                    >
                      ✕ Cancelar Demanda
                    </button>
                  ) : (
                    <>
                      <strong
                        style={{
                          display:
                            'block',
                          marginBottom:
                            '8px',
                        }}
                      >
                        Motivo do cancelamento
                      </strong>
                      <textarea
                        value={
                          motivoCancelamento
                        }
                        onChange={(event) =>
                          setMotivoCancelamento(
                            event.target.value
                          )
                        }
                        placeholder="Informe obrigatoriamente o motivo do cancelamento."
                        style={{
                          width:
                            '100%',
                          minHeight:
                            '80px',
                        }}
                      />
                      <div
                        style={{
                          display:
                            'flex',
                          gap:
                            '10px',
                          marginTop:
                            '10px',
                          flexWrap:
                            'wrap',
                        }}
                      >
                        <button
                          type="button"
                          className="btn-secundario"
                          onClick={() => {
                            setMotivoCancelamento(
                              ''
                            )
                            setMostrarCancelamento(
                              false
                            )
                          }}
                        >
                          Voltar
                        </button>
                        <button
                          type="button"
                          className="btn-principal"
                          onClick={
                            confirmarCancelamento
                          }
                        >
                          Confirmar Cancelamento
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}
          {/* =================================================
              DESCRIÇÃO
              ================================================= */}
          <div className="descricao-area">
            <span>
              DESCRIÇÃO
            </span>
            <p>
              {demanda.descricao ||
                'Nenhuma descrição registrada.'}
            </p>
          </div>
          {/* =================================================
              OBSERVAÇÕES
              ================================================= */}
          <div className="observacao-box">
            <span>
              OBSERVAÇÕES
            </span>
            <p>
              {demanda.observacao ||
                'Nenhuma observação registrada.'}
            </p>
          </div>
        </section>
        {/* ==================================================
            AÇÕES
            ================================================== */}
        <section className="detalhe-card">
          <div className="card-title">
            Ações
          </div>
          <div className="acoes-content">
            {/* ANALISTA */}
            <div className="campo-acao">
              <label>
                Responsável
              </label>
              <select
                value={
                  responsavelSelecionado
                }
                onChange={(event) =>
                  setResponsavelSelecionado(
                    event.target.value
                  )
                }
                disabled={
                  demanda.status ===
                    'Concluída' ||
                  demanda.status ===
                    'Cancelada'
                }
              >
                <option value="">
                  Não atribuído
                </option>
                {analistas.map(
                  (item) => (
                    <option
                      key={item.id}
                      value={item.nome}
                    >
                      {item.nome}
                    </option>
                  )
                )}
              </select>
            </div>
            {/* STATUS */}
            <div className="campo-acao">
              <label>
                Status
              </label>
              <select
                value={
                  statusSelecionado
                }
                onChange={(event) =>
                  selecionarStatus(
                    event.target.value
                  )
                }
                disabled={
                  demanda.status ===
                    'Concluída' ||
                  demanda.status ===
                    'Cancelada'
                }
              >
                {STATUS.map(
                  (item) => (
                    <option
                      key={item}
                      value={item}
                    >
                      {item}
                    </option>
                  )
                )}
              </select>
            </div>
            {/* RETOMAR ATENDIMENTO */}
            {demanda.status ===
              'Com Pendências' &&
            statusSelecionado ===
              'Com Pendências' &&
            !mostrarConclusao && (
              <div className="campo-acao">
                <label>
                  Ação
                </label>
                <button
                  type="button"
                  className="btn-principal"
                  style={{
                    width: '100%',
                    minHeight: '42px',
                    whiteSpace: 'nowrap',
                  }}
                  onClick={() => {
                    if (
                      !responsavelSelecionado.trim()
                    ) {
                      alert(
                        'Defina um Responsável antes de retomar o atendimento.'
                      )
                      return
                    }
                    setStatusSelecionado(
                      'Em Atendimento'
                    )
                  }}
                >
                  ▶ Retomar Atendimento
                </button>
              </div>
            )}
          </div>
        </section>
        {/* ==================================================
            PENDÊNCIA
            ================================================== */}
        {mostrarPendencia && (
          <section className="detalhe-card">
            <div className="card-title">
              Motivo da Pendência
            </div>
            <div className="comentarios-content">
              <textarea
                value={
                  motivoPendencia
                }
                onChange={(event) =>
                  setMotivoPendencia(
                    event.target.value
                  )
                }
                placeholder="Informe o motivo da pendência..."
              />
              <div className="comentario-actions">
                <button
                  className="btn-secundario"
                  type="button"
                  onClick={
                    cancelarPendencia
                  }
                >
                  Cancelar
                </button>
                <button
                  className="btn-principal"
                  type="button"
                  onClick={
                    confirmarPendencia
                  }
                >
                  Confirmar Pendência
                </button>
              </div>
            </div>
          </section>
        )}
        {/* ==================================================
            CONCLUSÃO
            ================================================== */}
        {mostrarConclusao && (
          <section className="detalhe-card">
            <div className="card-title">
              Concluir Demanda
            </div>
            <div className="comentarios-content">
              <textarea
                value={
                  comentarioConclusao
                }
                onChange={(event) =>
                  setComentarioConclusao(
                    event.target.value
                  )
                }
                placeholder="Informe obrigatoriamente o comentário de conclusão..."
              />
              <div className="comentario-actions">
                <button
                  className="btn-secundario"
                  type="button"
                  onClick={
                    cancelarConclusao
                  }
                >
                  Cancelar
                </button>
                <button
                  className="btn-principal"
                  type="button"
                  onClick={
                    confirmarConclusao
                  }
                >
                  Concluir Demanda
                </button>
              </div>
            </div>
          </section>
        )}
        {/* ==================================================
            COMENTÁRIOS
            ================================================== */}
        <section className="detalhe-card">
          <div className="card-title">
            Comentários
          </div>
          <div className="comentarios-content">
            <textarea
              value={
                comentario
              }
              onChange={(event) =>
                setComentario(
                  event.target.value
                )
              }
              placeholder="Digite um comentário sobre esta demanda..."
            />
            <div className="comentario-actions">
              <button
                className="btn-principal"
                type="button"
                disabled={
                  !comentario.trim()
                }
                onClick={
                  adicionarComentarioLocal
                }
              >
                + Adicionar Comentário
              </button>
            </div>
            {comentariosLocais.length ===
            0 ? (
              <div className="sem-registros">
                Nenhum comentário registrado.
              </div>
            ) : (
              <div className="lista-comentarios">
                {comentariosLocais.map(
                  (item) => {
                    const pendente =
                      comentariosPendentes.includes(
                        item.id
                      )
                    return (
                      <div
                        className="comentario-item"
                        key={item.id}
                      >
                        <div className="comentario-topo">
                          <strong>
                            {item.usuario}
                          </strong>
                          <span>
                            {formatarDataHora(
                              item.data
                            )}
                          </span>
                        </div>
                        <div className="comentario-texto">
                          {item.texto}
                        </div>
                        {pendente && (
                          <div className="comentario-rodape">
                            <span className="aviso-pendente">
                              Ainda não salvo
                            </span>
                            <button
                              type="button"
                              className="btn-excluir-pendente"
                              onClick={() =>
                                excluirComentario(
                                  item.id
                                )
                              }
                            >
                              Excluir
                            </button>
                          </div>
                        )}
                      </div>
                    )
                  }
                )}
              </div>
            )}
          </div>
        </section>
        {/* ==================================================
            ANEXOS
            ================================================== */}
        <section className="detalhe-card">
          <div className="card-title">
            Evidências e Arquivos
          </div>
          <div className="arquivos-content">
            <div className="arquivos-instrucoes">
              <div>
                <strong>
                  Anexe evidências e arquivos relacionados à demanda.
                </strong>
                <span>
                  Formatos aceitos: PDF, DOC, DOCX, XLS, XLSX, CSV, TXT, PNG, JPG e JPEG.
                </span>
                <span>
                  Limite máximo: 20 MB por arquivo.
                </span>
              </div>
              <label className="btn-anexar">
                📎 Anexar arquivo
                <input
                  type="file"
                  hidden
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.png,.jpg,.jpeg"
                  onChange={
                    selecionarArquivo
                  }
                />
              </label>
            </div>
            {arquivosLocais.length ===
            0 ? (
              <div className="arquivos-vazio">
                <div className="clip-icon">
                  📎
                </div>
                <strong>
                  Nenhum arquivo anexado
                </strong>
                <span>
                  As evidências e arquivos relacionados à demanda aparecerão aqui.
                </span>
              </div>
            ) : (
              <div className="lista-arquivos">
                {arquivosLocais.map(
                  (arquivo) => {
                    const pendente =
                      arquivosPendentes.includes(
                        arquivo.id
                      )
                    return (
                      <div
                        className="arquivo-item"
                        key={arquivo.id}
                      >
                        <div className="arquivo-info">
                          <div className="arquivo-icone">
                            📄
                          </div>
                          <div>
                            <strong>
                              {arquivo.nome}
                            </strong>
                            <span>
                              {formatarTamanho(
                                arquivo.tamanho
                              )}
                              {' • Anexado por '}
                              {arquivo.usuario}
                              {' • '}
                              {formatarDataHora(
                                arquivo.data
                              )}
                            </span>
                          </div>
                        </div>
                        <div className="arquivo-acoes">
                          {pendente && (
                            <button
                              type="button"
                              className="btn-excluir-pendente"
                              onClick={() =>
                                excluirArquivo(
                                  arquivo.id
                                )
                              }
                            >
                              Excluir
                            </button>
                          )}
                          <button
                            type="button"
                            className="btn-baixar"
                            onClick={() =>
                              baixarArquivo(
                                arquivo
                              )
                            }
                          >
                            ↓ Baixar
                          </button>
                        </div>
                      </div>
                    )
                  }
                )}
              </div>
            )}
          </div>
        </section>
        {/* ==================================================
            HISTÓRICO
            ================================================== */}
        <section className="detalhe-card">
          <div className="card-title">
            Histórico da Demanda
          </div>
          <div className="historico-content">
            {historicoLocal.length ===
            0 ? (
              <div className="historico-item">
                <div className="historico-bolinha" />
                <div>
                  <div className="historico-data">
                    {formatarDataHora(
                      demanda.dataAbertura ||
                        new Date().toISOString()
                    )}
                  </div>
                  <strong>
                    Demanda cadastrada
                  </strong>
                  <p>
                    Registro inicial da demanda.
                  </p>
                </div>
              </div>
            ) : (
              historicoLocal.map(
                (item) => {
                  const comentarioRelacionado =
                    item.tipo === 'comentario' &&
                    item.referenciaId
                      ? comentariosLocais.find(
                          (comentarioItem) =>
                            comentarioItem.id ===
                            item.referenciaId
                        )
                      : undefined
                  return (
                    <div
                      className="historico-item"
                      key={item.id}
                    >
                      <div className="historico-bolinha" />
                      <div className="historico-detalhes">
                        <div className="historico-data">
                          {formatarDataHora(
                            item.data
                          )}
                        </div>
                        <strong>
                          {item.titulo}
                        </strong>
                        {comentarioRelacionado ? (
                          <div className="historico-comentario-texto">
                            <span
                              className="historico-comentario-label"
                              style={{
                                display: 'block',
                                marginBottom: '4px',
                                color: '#2563eb',
                                fontSize: '11px',
                                fontWeight: 700,
                              }}
                            >
                              Comentário
                            </span>
                            <div
                              className="historico-comentario-conteudo"
                              style={{
                                color: '#334155',
                                fontSize: '13px',
                                lineHeight: 1.55,
                                whiteSpace: 'pre-wrap',
                              }}
                            >
                              {comentarioRelacionado.texto}
                            </div>
                          </div>
                        ) : (
                          <p>
                            {item.descricao}
                          </p>
                        )}
                        <div className="historico-comentario">
                          {item.usuario}
                        </div>
                        {item.motivo && (
                          <div
                            style={{
                              marginTop:
                                '6px',
                              fontSize:
                                '12px',
                              color:
                                '#526579',
                            }}
                          >
                            <strong>
                              Motivo:
                            </strong>{' '}
                            {item.motivo}
                          </div>
                        )}
                      </div>
                    </div>
                  )
                }
              )
            )}
          </div>
        </section>
        </div>
      </div>
    </MenuPrincipal>
    </>
  )
}
export default DetalheDemandaPage
