// ============================================================
// GESTÃO DE DEMANDAS DE TI
// V2.9 — APLICAÇÃO PRINCIPAL — PRIORIDADE DE ATENDIMENTO EDITÁVEL
// ============================================================
// ARQUIVO: src/App.tsx
//
// RESPONSABILIDADES:
// - Controle central da aplicação
// - Login e sessão
// - Navegação
// - Persistência das demandas
// - Criação de demandas
// - Alteração de status
// - Distribuição / redistribuição para Responsáveis
// - Alteração de prioridade
// - Alteração manual de prazo
// - Reabertura
// - Cancelamento com motivo obrigatório
// - Comentários
// - Anexos
// - Auditoria
// - Notificações
// - Compatibilidade com dados antigos
// - Controle de SLA
// ============================================================

import { useState } from 'react'

import Dashboard from './pages/Dashboard'
import TodasDemandas from './pages/TodasDemandas'
import NovaDemanda from './pages/NovaDemanda'
import DetalheDemandaPage from './pages/DetalheDemanda'
import Feriados from './pages/Feriados'
import Login from './pages/Login'
import MinhasDemandas from './pages/MinhasDemandas'
import DashboardAnalista from './pages/DashboardAnalista'
import ConfiguracoesAnalista from './pages/ConfiguracoesAnalista'
import Administracao from './pages/Administracao'
import Clientes from './pages/Clientes'
import Responsaveis from './pages/Responsaveis'
import Relatorios from './pages/Relatorios'
import TrocarSenha from './pages/TrocarSenha'
import Configuracoes from './pages/Configuracoes'

import type {
  Arquivo,
  Comentario,
  Demanda,
  Historico,
  Usuario,
} from './types'
import { ehPerfilOperacional } from './types'

import {
  carregarClientes,
  carregarSistemas,
  carregarTipos,
  carregarUsuarios,
  salvarUsuarios,
  carregarSessao,
  limparSessao,
  salvarSessao,
  type SessaoUsuario,
} from './services/storage'

import { registrarAlteracao } from './services/auditoria'
import { criarNotificacao as criarNotificacaoBase } from './services/notificacoes'

type ConfiguracaoNotificacao = 'atrasadas' | 'proximoVencimento' | 'atribuicao' | 'conclusao' | 'reabertura' | 'cancelamento'

function notificacaoHabilitada(campo: ConfiguracaoNotificacao): boolean {
  const padrao: Record<ConfiguracaoNotificacao, boolean> = {
    atrasadas: true, proximoVencimento: true, atribuicao: true,
    conclusao: true, reabertura: true, cancelamento: true,
  }
  try {
    const salvo = localStorage.getItem('configuracoes_sistema')
    if (!salvo) return true
    const dados = JSON.parse(salvo) as { notificacoes?: Partial<Record<ConfiguracaoNotificacao, boolean>> }
    return dados.notificacoes?.[campo] ?? padrao[campo]
  } catch {
    return padrao[campo]
  }
}

function identificarConfiguracaoNotificacao(titulo: string): ConfiguracaoNotificacao | null {
  const valor = titulo.trim().toLowerCase()
  if (valor === 'nova demanda atribuída' || valor === 'demanda atribuída') return 'atribuicao'
  if (valor === 'demanda concluída') return 'conclusao'
  if (valor === 'demanda reaberta') return 'reabertura'
  if (valor === 'demanda cancelada') return 'cancelamento'
  return null
}

function criarNotificacao(notificacao: Parameters<typeof criarNotificacaoBase>[0]) {
  const campo = identificarConfiguracaoNotificacao(notificacao.titulo)
  if (campo && !notificacaoHabilitada(campo)) return
  criarNotificacaoBase(notificacao)
}

import { diasPrazoPorPrioridade as obterDiasSLAConfigurados, diasSLACombinado, PRIORIDADES_ATENDIMENTO } from './sla'

// ============================================================
// USUÁRIO PADRÃO
// ============================================================

const USUARIO_ATUAL = 'Usuário atual'

// ============================================================
// STATUS OFICIAIS
// ============================================================

const STATUS_OFICIAIS = [
  'Nova',
  'Aguardando',
  'Em Atendimento',
  'Com Pendências',
  'Concluída',
  'Cancelada',
]

// ============================================================
// FLUXO OFICIAL DA DEMANDA
// ------------------------------------------------------------
// Nova nasce no cadastro e não deve ser usada como destino de
// fluxo operacional. Conclusão e cancelamento são finais; a
// reabertura utiliza uma operação própria e motivo obrigatório.
// ============================================================

const TRANSICOES_PERMITIDAS: Record<string, string[]> = {
  Nova: ['Aguardando', 'Em Atendimento', 'Cancelada'],
  Aguardando: ['Em Atendimento', 'Cancelada'],
  'Em Atendimento': ['Aguardando', 'Com Pendências', 'Concluída', 'Cancelada'],
  'Com Pendências': ['Em Atendimento', 'Concluída', 'Cancelada'],
  Concluída: [],
  Cancelada: [],
}

function ehGestor(sessaoAtual: SessaoUsuario | null): boolean {
  return sessaoAtual?.perfil === 'Gestor/Administrador' || String(sessaoAtual?.perfil) === 'Gestor'
}

// Perfis que podem ser definidos como Responsável pela Demanda.
// Mantemos a validação centralizada para que criação, redistribuição,
// reabertura e alteração de status utilizem exatamente a mesma regra.
const PERFIS_RESPONSAVEIS = new Set([
  'Gestor/Administrador',
  'Gestor',
  'Analista',
  'Desenvolvedor',
  'Estagiário',
])

function podeSerResponsavel(usuario: Usuario): boolean {
  return (
    usuario.status === 'Ativo' &&
    PERFIS_RESPONSAVEIS.has(String(usuario.perfil))
  )
}

function transicaoPermitida(statusAnterior: string, novoStatus: string): boolean {
  if (statusAnterior === novoStatus) return true
  return TRANSICOES_PERMITIDAS[statusAnterior]?.includes(novoStatus) ?? false
}

// ============================================================
// CRITICIDADES
// ============================================================

const PRIORIDADES = [
  'Crítica',
  'Alta',
  'Média',
  'Baixa',
]

// ============================================================
// SLA
// ============================================================

// ============================================================
// DATA / HORA
// ============================================================

function agoraISO(): string {
  return new Date().toISOString()
}

// ============================================================
// DATA LOCAL NO PADRÃO YYYY-MM-DD
// ============================================================

function dataLocalISO(data = new Date()): string {
  const ano = data.getFullYear()
  const mes = String(data.getMonth() + 1).padStart(2, '0')
  const dia = String(data.getDate()).padStart(2, '0')

  return `${ano}-${mes}-${dia}`
}

// ============================================================
// FERIADOS CADASTRADOS
// ============================================================

function feriadosCadastrados(): string[] {
  try {
    const dados = JSON.parse(
      localStorage.getItem('feriados') || '[]'
    )

    if (!Array.isArray(dados)) {
      return []
    }

    return dados
      .filter((item) => {
        if (typeof item === 'string') {
          return true
        }

        return item?.ativo !== false
      })
      .map((item) => {
        const valor =
          typeof item === 'string'
            ? item
            : item &&
                typeof item.data === 'string'
              ? item.data
              : ''

        if (/^\d{2}\/\d{2}\/\d{4}$/.test(valor)) {
          const [
            dia,
            mes,
            ano,
          ] = valor.split('/')

          return `${ano}-${mes}-${dia}`
        }

        return valor
      })
      .filter(Boolean)
  } catch {
    return []
  }
}

// ============================================================
// DIA ÚTIL
// ============================================================

function ehDiaUtil(data: Date): boolean {
  const diaSemana = data.getDay()

  if (
    diaSemana === 0 ||
    diaSemana === 6
  ) {
    return false
  }

  const chave = dataLocalISO(data)

  return !feriadosCadastrados().includes(chave)
}

// ============================================================
// ADICIONAR DIAS ÚTEIS
// ============================================================

function adicionarDiasUteis(
  dataInicial: Date,
  quantidade: number
): Date {
  const resultado = new Date(dataInicial)

  resultado.setHours(
    0,
    0,
    0,
    0
  )

  let adicionados = 0

  while (
    adicionados < quantidade
  ) {
    resultado.setDate(
      resultado.getDate() + 1
    )

    if (
      ehDiaUtil(resultado)
    ) {
      adicionados += 1
    }
  }

  return resultado
}

// ============================================================
// PRAZO POR CRITICIDADE
// ============================================================

function diasPrazoPorPrioridade(
  criticidade: string,
  prioridadeAtendimento?: string
): number {
  return prioridadeAtendimento
    ? diasSLACombinado(criticidade, prioridadeAtendimento)
    : obterDiasSLAConfigurados(criticidade)
}

// ============================================================
// CALCULAR PRAZO
// ============================================================

function calcularPrazo(
  criticidade: string,
  dataAbertura = new Date(),
  prioridadeAtendimento?: string
): string {
  return dataLocalISO(
    adicionarDiasUteis(
      dataAbertura,
      diasPrazoPorPrioridade(criticidade, prioridadeAtendimento)
    )
  )
}

// ============================================================
// HISTÓRICO
// ============================================================

function criarHistorico(
  tipo: string,
  titulo: string,
  descricao: string,
  referenciaId?: number,
  extras?: {
    valorAnterior?: string
    valorNovo?: string
    motivo?: string
  }
): Historico {
  return {
    id:
      Date.now() +
      Math.floor(
        Math.random() * 1000
      ),

    tipo,

    titulo,

    descricao,

    data: agoraISO(),

    usuario:
      nomeUsuarioAtualGlobal,

    referenciaId,

    ...extras,
  }
}

// ============================================================
// REFERÊNCIA DO USUÁRIO ATUAL
//
// Mantida fora do componente apenas para permitir que a função
// de histórico continue simples.
// Ela é atualizada dentro do App a cada render.
// ============================================================

let nomeUsuarioAtualGlobal =
  USUARIO_ATUAL

// ============================================================
// NORMALIZAÇÃO DAS DEMANDAS
// ============================================================

function normalizarDemanda(
  demanda: Demanda
): Demanda {
  // Campo `prioridade` era utilizado historicamente para guardar a criticidade.
  // Mantemos essa compatibilidade enquanto normalizamos os novos campos.
  const criticidadeOriginal =
    demanda.criticidade || demanda.prioridade

  const criticidade =
    criticidadeOriginal === 'Urgente'
      ? 'Crítica'
      : PRIORIDADES.includes(criticidadeOriginal)
        ? criticidadeOriginal
        : 'Média'

  const prioridadeLegadaParaAtendimento: Record<string, string> = {
    'Crítica': 'P1 — Imediata',
    'Alta': 'P2 — Urgente',
    'Média': 'P3 — Normal',
    'Baixa': 'P4 — Planejada',
    'Urgente': 'P1 — Imediata',
  }

  const prioridadeAtendimento =
    PRIORIDADES_ATENDIMENTO.includes(demanda.prioridadeAtendimento as typeof PRIORIDADES_ATENDIMENTO[number])
      ? demanda.prioridadeAtendimento!
      : prioridadeLegadaParaAtendimento[criticidadeOriginal] || prioridadeLegadaParaAtendimento[criticidade]

  const dataAbertura =
    demanda.dataAbertura ||
    agoraISO()

  let status =
    demanda.status || 'Nova'

  // Compatibilidade com versões antigas.
  if (
    status === 'Em Processo' ||
    status === 'Em análise'
  ) {
    status = 'Em Atendimento'
  }

  if (
    status === 'Pendente'
  ) {
    status = 'Com Pendências'
  }

  if (
    !STATUS_OFICIAIS.includes(status)
  ) {
    status = demanda.responsavel
      ? 'Em Atendimento'
      : 'Nova'
  }

  return {
    ...demanda,

    status,

    criticidade,

    prioridade: criticidade,

    prioridadeAtendimento,

    responsavel:
      demanda.responsavel || '',

    cliente:
      demanda.cliente || '',

    sistema:
      demanda.sistema || '',

    tipo:
      demanda.tipo || '',

    dataAbertura,

    prazo:
      demanda.prazo ||
      calcularPrazo(
        criticidade,
        new Date(dataAbertura),
        prioridadeAtendimento
      ),

    prazoDiasUteis:
      demanda.prazoDiasUteis ||
      diasPrazoPorPrioridade(
        criticidade,
        prioridadeAtendimento
      ),

    prazoManual:
      Boolean(
        demanda.prazoManual
      ),

    comentarios:
      Array.isArray(
        demanda.comentarios
      )
        ? demanda.comentarios
        : [],

    arquivos:
      Array.isArray(
        demanda.arquivos
      )
        ? demanda.arquivos
        : [],

    historico:
      Array.isArray(
        demanda.historico
      )
        ? demanda.historico
        : [],

    periodosPendencia:
      Array.isArray(
        demanda.periodosPendencia
      )
        ? demanda.periodosPendencia
        : [],
  }
}

// ============================================================
// CARREGAR DEMANDAS
// ============================================================

function carregarDemandas(): Demanda[] {
  const salvas =
    localStorage.getItem(
      'demandas'
    )

  if (!salvas) {
    return []
  }

  try {
    const dados =
      JSON.parse(salvas)

    if (!Array.isArray(dados)) {
      return []
    }

    const normalizadas =
      dados.map(
        normalizarDemanda
      )

    try {
      localStorage.setItem(
        'demandas',
        JSON.stringify(
          normalizadas
        )
      )
    } catch {
      // O sistema continua funcionando.
    }

    return normalizadas
  } catch {
    return []
  }
}

// ============================================================
// DIAS ÚTEIS CONSUMIDOS
//
// Não conta o dia de abertura.
// Desconsidera períodos de pendência.
// ============================================================

function diasUteisConsumidosSemPendencia(
  demanda: Demanda,
  agora = new Date()
): number {
  if (
    !demanda.dataAbertura
  ) {
    return 0
  }

  const inicio =
    new Date(
      demanda.dataAbertura
    )

  const fim =
    demanda.status === 'Concluída' &&
    demanda.dataConclusao
      ? new Date(
          demanda.dataConclusao
        )
      : agora

  if (
    Number.isNaN(
      inicio.getTime()
    ) ||
    Number.isNaN(
      fim.getTime()
    ) ||
    fim <= inicio
  ) {
    return 0
  }

  const periodos =
    demanda.periodosPendencia ||
    []

  const inicioDia =
    new Date(inicio)

  inicioDia.setHours(
    0,
    0,
    0,
    0
  )

  const fimDia =
    new Date(fim)

  fimDia.setHours(
    0,
    0,
    0,
    0
  )

  let cursor =
    new Date(
      inicioDia
    )

  let dias = 0

  while (
    cursor < fimDia
  ) {
    cursor.setDate(
      cursor.getDate() + 1
    )

    if (
      cursor > fimDia
    ) {
      break
    }

    if (
      !ehDiaUtil(cursor)
    ) {
      continue
    }

    const diaAtual =
      new Date(cursor)

    diaAtual.setHours(
      0,
      0,
      0,
      0
    )

    const emPendencia =
      periodos.some(
        (periodo) => {
          const inicioPendencia =
            new Date(
              periodo.inicio
            )

          const fimPendencia =
            periodo.fim
              ? new Date(
                  periodo.fim
                )
              : agora

          if (
            Number.isNaN(
              inicioPendencia.getTime()
            ) ||
            Number.isNaN(
              fimPendencia.getTime()
            )
          ) {
            return false
          }

          inicioPendencia.setHours(
            0,
            0,
            0,
            0
          )

          fimPendencia.setHours(
            0,
            0,
            0,
            0
          )

          return (
            diaAtual >=
              inicioPendencia &&
            diaAtual <=
              fimPendencia
          )
        }
      )

    if (
      !emPendencia
    ) {
      dias += 1
    }
  }

  return dias
}

// ============================================================
// COMPONENTE PRINCIPAL
// ============================================================

function App() {

  const [
    pagina,
    setPagina,
  ] = useState(() => {
    const sessaoInicial = carregarSessao()
    return ehPerfilOperacional(sessaoInicial?.perfil)
      ? 'dashboard-analista'
      : 'dashboard'
  })

  const [
    demandaSelecionada,
    setDemandaSelecionada,
  ] =
    useState<Demanda | null>(
      null
    )

  const [
    usuarioTrocaSenha,
    setUsuarioTrocaSenha,
  ] = useState<Usuario | null>(null)

  const [
    demandas,
    setDemandas,
  ] = useState<Demanda[]>(
    carregarDemandas
  )

  // ==========================================================
  // SESSÃO
  // ==========================================================

  const [
    sessao,
    setSessao,
  ] = useState<SessaoUsuario | null>(
    carregarSessao
  )

  const nomeUsuarioAtual =
    sessao?.nome ||
    USUARIO_ATUAL

  nomeUsuarioAtualGlobal =
    nomeUsuarioAtual

  const usuarioAtual =
    sessao
      ? carregarUsuarios().find(
          (usuario) =>
            usuario.id ===
            sessao.usuarioId
        ) || {
          id: sessao.usuarioId,

          nome: sessao.nome,

          login: sessao.login,

          email: '',

          perfil: sessao.perfil,

          status:
            'Ativo' as const,

          criadoEm: '',
        }
      : null

  const usuariosCadastrados =
    carregarUsuarios()

  const clientesCadastrados =
    carregarClientes()

  const sistemasCadastrados =
    carregarSistemas()

  const tiposCadastrados =
    carregarTipos()

  // A lista abaixo mantém o nome interno original para preservar
  // a compatibilidade com as telas existentes, mas agora contém
  // todos os perfis ativos que podem ser Responsável pela Demanda.
  const analistasAtivos =
    usuariosCadastrados.filter(
      podeSerResponsavel
    )

  // ==========================================================
  // LOGIN
  // ==========================================================

  function realizarLogin(
    usuario: Usuario,
    exigirTrocaSenha = false
  ) {
    // ========================================================
    // REGISTRA O ÚLTIMO ACESSO DO USUÁRIO
    //
    // O registro acontece imediatamente após a autenticação,
    // inclusive quando o usuário precisa trocar a senha no
    // primeiro acesso.
    // ========================================================

    const dataUltimoAcesso = agoraISO()

    const usuarios = carregarUsuarios()

    const usuariosAtualizados = usuarios.map((item) =>
      item.id === usuario.id
        ? {
            ...item,
            ultimoAcesso: dataUltimoAcesso,
          }
        : item
    )

    salvarUsuarios(usuariosAtualizados)

    const usuarioAtualizado =
      usuariosAtualizados.find(
        (item) => item.id === usuario.id
      ) || {
        ...usuario,
        ultimoAcesso: dataUltimoAcesso,
      }

    // ========================================================
    // PRIMEIRO ACESSO / TROCA OBRIGATÓRIA DE SENHA
    // ========================================================

    if (exigirTrocaSenha) {
      setUsuarioTrocaSenha(
        usuarioAtualizado
      )

      return
    }

    // ========================================================
    // CRIA A SESSÃO
    // ========================================================

    const novaSessao:
      SessaoUsuario = {
      usuarioId:
        usuarioAtualizado.id,

      nome:
        usuarioAtualizado.nome,

      perfil:
        usuarioAtualizado.perfil,

      login:
        usuarioAtualizado.login,
    }

    salvarSessao(
      novaSessao
    )

    setSessao(
      novaSessao
    )

    setPagina(
      ehPerfilOperacional(
        usuarioAtualizado.perfil
      )
        ? 'dashboard-analista'
        : 'dashboard'
    )
  }

  async function salvarNovaSenha(
    novaSenha: string
  ) {
    if (!usuarioTrocaSenha) {
      return
    }

    const bytes = new TextEncoder().encode(novaSenha)
    const digest = await window.crypto.subtle.digest(
      'SHA-256',
      bytes
    )

    const senhaHash = Array.from(new Uint8Array(digest))
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('')

    const usuarios = carregarUsuarios() as Array<
      Usuario & {
        senhaHash?: string
        exigirTrocaSenha?: boolean
      }
    >

    const atualizados = usuarios.map((item) =>
      item.id === usuarioTrocaSenha.id
        ? {
            ...item,
            senhaHash,
            exigirTrocaSenha: false,
            atualizadoEm: agoraISO(),
          }
        : item
    )

    salvarUsuarios(atualizados)

    registrarAlteracao(
      'usuario',
      usuarioTrocaSenha.id,
      'troca_senha_primeiro_acesso',
      `O usuário ${usuarioTrocaSenha.nome} concluiu a troca da senha no primeiro acesso.`,
      usuarioTrocaSenha.nome
    )

    const usuarioAtualizado = atualizados.find(
      (item) => item.id === usuarioTrocaSenha.id
    ) || usuarioTrocaSenha

    setUsuarioTrocaSenha(null)

    const novaSessao: SessaoUsuario = {
      usuarioId: usuarioAtualizado.id,
      nome: usuarioAtualizado.nome,
      perfil: usuarioAtualizado.perfil,
      login: usuarioAtualizado.login,
    }

    salvarSessao(novaSessao)
    setSessao(novaSessao)
    setPagina(
      ehPerfilOperacional(usuarioAtualizado.perfil)
        ? 'dashboard-analista'
        : 'dashboard'
    )
  }

  // ==========================================================
  // LOGOUT
  // ==========================================================

  function realizarLogout() {
    limparSessao()

    setSessao(
      null
    )

    setDemandaSelecionada(
      null
    )

    setUsuarioTrocaSenha(null)

    setPagina(
      'login'
    )
  }

  // ==========================================================
  // SALVAR TODAS AS DEMANDAS
  // ==========================================================

  function salvarDemandas(
    demandasAtualizadas: Demanda[]
  ) {
    const normalizadas =
      demandasAtualizadas.map(
        normalizarDemanda
      )

    setDemandas(
      normalizadas
    )

    try {
      localStorage.setItem(
        'demandas',
        JSON.stringify(
          normalizadas
        )
      )
    } catch {
      // Mantém funcionamento da interface.
    }

    if (
      demandaSelecionada
    ) {
      const selecionada =
        normalizadas.find(
          (item) =>
            item.id ===
            demandaSelecionada.id
        )

      if (
        selecionada
      ) {
        setDemandaSelecionada(
          selecionada
        )
      }
    }
  }

  // ==========================================================
  // ATUALIZAR UMA DEMANDA
  // ==========================================================

  function atualizarDemanda(
    id: number,
    atualizador: (
      demanda: Demanda
    ) => Demanda
  ) {
    setDemandas(
      (atuais) => {
        const demandasAtualizadas =
          atuais.map(
            (demanda) =>
              demanda.id === id
                ? normalizarDemanda(
                    atualizador(
                      normalizarDemanda(
                        demanda
                      )
                    )
                  )
                : demanda
          )

        try {
          localStorage.setItem(
            'demandas',
            JSON.stringify(
              demandasAtualizadas
            )
          )
        } catch {
          // Mantém interface funcionando.
        }

        const selecionada =
          demandasAtualizadas.find(
            (item) =>
              item.id === id
          )

        if (
          selecionada
        ) {
          setDemandaSelecionada(
            selecionada
          )
        }

        return demandasAtualizadas
      }
    )
  }

  // ==========================================================
  // NOVA DEMANDA
  // ==========================================================

  function salvarDemanda(
    demanda: Omit<
      Demanda,
      'id' | 'status'
    >
  ) {
    const agora =
      new Date()

    const agoraTexto =
      agora.toISOString()

    const id =
      Date.now()

    const criticidadeInformada =
      demanda.criticidade || demanda.prioridade

    const criticidade =
      PRIORIDADES.includes(criticidadeInformada)
        ? criticidadeInformada
        : 'Média'

    const prioridadeLegadaParaAtendimento: Record<string, string> = {
      'Crítica': 'P1 — Imediata',
      'Alta': 'P2 — Urgente',
      'Média': 'P3 — Normal',
      'Baixa': 'P4 — Planejada',
    }

    const prioridadeAtendimento =
      PRIORIDADES_ATENDIMENTO.includes(demanda.prioridadeAtendimento as typeof PRIORIDADES_ATENDIMENTO[number])
        ? demanda.prioridadeAtendimento!
        : prioridadeLegadaParaAtendimento[criticidade]

    const prazo =
      demanda.prazo ||
      calcularPrazo(
        criticidade,
        agora,
        prioridadeAtendimento
      )

    const responsavel =
      demanda.responsavel?.trim() ||
      ''

    if (
      responsavel &&
      !analistasAtivos.some(
        (usuario) =>
          usuario.nome === responsavel
      )
    ) {
      window.alert(
        'Selecione um Responsável ativo cadastrado no sistema.'
      )
      return
    }

    const novaDemanda =
      normalizarDemanda({
        ...demanda,

        id,

        criticidade,

        prioridade: criticidade,

        prioridadeAtendimento,

        prazo,

        dataAbertura:
          demanda.dataAbertura ||
          agoraTexto,

        usuarioCriacao:
          demanda.usuarioCriacao ||
          nomeUsuarioAtual,

        prazoDiasUteis:
          diasPrazoPorPrioridade(
            criticidade,
            prioridadeAtendimento
          ),

        prazoManual: false,

        status:
          responsavel
            ? 'Em Atendimento'
            : 'Nova',

        comentarios: [],

        arquivos: demanda.arquivos || [],

        historico: [
          {
            id:
              id + 1,

            tipo:
              'criacao',

            titulo:
              'Demanda cadastrada',

            descricao:
              responsavel
                ? 'A demanda foi cadastrada e atribuída para atendimento.'
                : 'A demanda foi cadastrada e permanece como Nova, aguardando triagem e atribuição de um Responsável.',

            data:
              agoraTexto,

            usuario:
              nomeUsuarioAtual,

            referenciaId:
              id,
          },
          ...(demanda.historico || []),
        ],
      })

    const atualizadas = [
      ...demandas,
      novaDemanda,
    ]

    salvarDemandas(
      atualizadas
    )

    registrarAlteracao(
      'demanda',
      id,
      'criacao',
      `Demanda DEM-${String(id).padStart(5, '0')} cadastrada.`,
      nomeUsuarioAtual
    )

    if (
      responsavel
    ) {
      criarNotificacao({
        tipo:
          'informativo',

        titulo:
          'Nova demanda atribuída',

        descricao:
          `A demanda DEM-${String(id).padStart(5, '0')} foi atribuída para ${responsavel}.`,

        demandaId:
          id,

        prioridade: criticidade,
      })
    }

    setPagina(
      'todas-demandas'
    )
  }

  // ==========================================================
  // ALTERAR CRITICIDADE
  //
  // REGRA:
  // - O tempo já consumido não é zerado.
  // - O novo SLA é aplicado somente sobre o saldo.
  // ==========================================================

  function alterarPrioridade(
    id: number,
    novaPrioridade: string,
    motivo?: string
  ): boolean {
    if (!ehGestor(sessao)) return false
    if (!PRIORIDADES.includes(novaPrioridade)) return false

    const demandaAlvo = demandas.find((item) => item.id === id)
    if (!demandaAlvo) return false

    if (demandaAlvo.status === 'Concluída' || demandaAlvo.status === 'Cancelada') {
      window.alert(
        'Demandas concluídas ou canceladas não podem ter a criticidade alterada. Reabra a demanda antes, quando aplicável.'
      )
      return false
    }

    const criticidadeAtualAlvo = demandaAlvo.criticidade || demandaAlvo.prioridade
    if (criticidadeAtualAlvo === novaPrioridade) return false

    // Em prazo manual, OK recalcula com o SLA combinado; Cancelar preserva a data manual.
    let recalcularPrazo = true
    if (demandaAlvo.prazoManual) {
      recalcularPrazo = window.confirm(
        `Esta demanda possui prazo definido manualmente (${demandaAlvo.prazo || 'sem data'}).\n\n` +
        'Deseja recalcular o prazo conforme o SLA combinado de Criticidade e Prioridade de Atendimento?\n\n' +
        'OK = Recalcular o prazo conforme o SLA.\n' +
        'Cancelar = Preservar o prazo manual atual.\n\n' +
        'A alteração da Criticidade será aplicada em qualquer uma das opções.'
      )
    }

    const motivoFinal = motivo?.trim() || 'Alteração de criticidade realizada pelo Gestor.'

    atualizarDemanda(id, (demanda) => {
      if (demanda.status === 'Concluída' || demanda.status === 'Cancelada') return demanda

      const criticidadeAtual = demanda.criticidade || demanda.prioridade
      if (criticidadeAtual === novaPrioridade) return demanda

      const consumidos = diasUteisConsumidosSemPendencia(demanda)
      const novoSla = diasPrazoPorPrioridade(novaPrioridade, demanda.prioridadeAtendimento)
      const saldo = Math.max(novoSla - consumidos, 0)
      const preservarPrazoManual = Boolean(demanda.prazoManual && !recalcularPrazo)
      const novoPrazo = preservarPrazoManual
        ? demanda.prazo
        : dataLocalISO(adicionarDiasUteis(new Date(), saldo))
      const agora = agoraISO()
      const decisaoPrazo = preservarPrazoManual
        ? `Prazo manual preservado: ${demanda.prazo}.`
        : `Prazo recalculado conforme SLA: ${novoPrazo}.`
      const descricao =
        `Criticidade alterada de "${criticidadeAtual}" para "${novaPrioridade}". ` +
        `Tempo já consumido: ${consumidos} dia(s) útil(eis). ` +
        `Novo SLA combinado: ${novoSla} dia(s) útil(eis). ` +
        `Saldo considerado: ${saldo} dia(s) útil(eis). ${decisaoPrazo}`

      registrarAlteracao(
        'demanda', id, 'alteracao_prioridade', descricao, nomeUsuarioAtual,
        {
          valorAnterior: criticidadeAtual,
          valorNovo: novaPrioridade,
          motivo: `${motivoFinal} ${decisaoPrazo}`,
        }
      )

      const historico: Historico = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        tipo: 'prioridade',
        titulo: 'Criticidade alterada',
        descricao,
        data: agora,
        usuario: nomeUsuarioAtual,
        referenciaId: id,
        valorAnterior: criticidadeAtual,
        valorNovo: novaPrioridade,
        motivo: `${motivoFinal} ${decisaoPrazo}`,
      }

      return {
        ...demanda,
        criticidade: novaPrioridade,
        prioridade: novaPrioridade,
        prazo: novoPrazo,
        prazoDiasUteis: novoSla,
        prazoManual: preservarPrazoManual,
        motivoAlteracaoPrioridade: motivoFinal,
        historico: [historico, ...(demanda.historico || [])],
      }
    })

    return true
  }

  // ==========================================================
  // ALTERAR PRIORIDADE DE ATENDIMENTO
  // Em prazo manual, o Gestor escolhe preservar ou recalcular o prazo.
  // ==========================================================
  function alterarPrioridadeAtendimento(
    id: number,
    novaPrioridadeAtendimento: string,
    motivo?: string
  ): boolean {
    if (!ehGestor(sessao)) return false
    if (!PRIORIDADES_ATENDIMENTO.includes(novaPrioridadeAtendimento as typeof PRIORIDADES_ATENDIMENTO[number])) return false

    const demandaAlvo = demandas.find((item) => item.id === id)
    if (!demandaAlvo) return false

    if (demandaAlvo.status === 'Concluída' || demandaAlvo.status === 'Cancelada') {
      window.alert('Demandas concluídas ou canceladas não podem ter a Prioridade de Atendimento alterada. Reabra a demanda antes, quando aplicável.')
      return false
    }

    const prioridadeAlvoAtual = demandaAlvo.prioridadeAtendimento || ''
    if (prioridadeAlvoAtual === novaPrioridadeAtendimento) return false

    let recalcularPrazo = true
    if (demandaAlvo.prazoManual) {
      recalcularPrazo = window.confirm(
        `Esta demanda possui prazo definido manualmente (${demandaAlvo.prazo || 'sem data'}).\n\n` +
        'Deseja recalcular o prazo conforme o SLA combinado de Criticidade e Prioridade de Atendimento?\n\n' +
        'OK = Recalcular o prazo conforme o SLA.\n' +
        'Cancelar = Preservar o prazo manual atual.\n\n' +
        'A alteração da Prioridade de Atendimento será aplicada em qualquer uma das opções.'
      )
    }

    const motivoFinal = motivo?.trim() || 'Alteração de Prioridade de Atendimento realizada pelo Gestor.'

    atualizarDemanda(id, (demanda) => {
      if (demanda.status === 'Concluída' || demanda.status === 'Cancelada') return demanda

      const prioridadeAtual = demanda.prioridadeAtendimento || ''
      if (prioridadeAtual === novaPrioridadeAtendimento) return demanda

      const criticidadeAtual = demanda.criticidade || demanda.prioridade || 'Média'
      const consumidos = diasUteisConsumidosSemPendencia(demanda)
      const novoSla = diasSLACombinado(criticidadeAtual, novaPrioridadeAtendimento)
      const saldo = Math.max(novoSla - consumidos, 0)
      const preservarPrazoManual = Boolean(demanda.prazoManual && !recalcularPrazo)
      const novoPrazo = preservarPrazoManual
        ? demanda.prazo
        : dataLocalISO(adicionarDiasUteis(new Date(), saldo))
      const agora = agoraISO()
      const decisaoPrazo = preservarPrazoManual
        ? `Prazo manual preservado: ${demanda.prazo}.`
        : `Prazo recalculado conforme SLA: ${novoPrazo}.`
      const descricao =
        `Prioridade de Atendimento alterada de "${prioridadeAtual || 'Não definida'}" para "${novaPrioridadeAtendimento}". ` +
        `Tempo já consumido: ${consumidos} dia(s) útil(eis). ` +
        `Novo SLA combinado: ${novoSla} dia(s) útil(eis). ` +
        `Saldo considerado: ${saldo} dia(s) útil(eis). ${decisaoPrazo}`

      registrarAlteracao(
        'demanda', id, 'alteracao_prioridade_atendimento', descricao, nomeUsuarioAtual,
        {
          valorAnterior: prioridadeAtual || 'Não definida',
          valorNovo: novaPrioridadeAtendimento,
          motivo: `${motivoFinal} ${decisaoPrazo}`,
        }
      )

      const historico: Historico = {
        id: Date.now() + Math.floor(Math.random() * 1000),
        tipo: 'prioridade_atendimento',
        titulo: 'Prioridade de Atendimento alterada',
        descricao,
        data: agora,
        usuario: nomeUsuarioAtual,
        referenciaId: id,
        valorAnterior: prioridadeAtual || 'Não definida',
        valorNovo: novaPrioridadeAtendimento,
        motivo: `${motivoFinal} ${decisaoPrazo}`,
      }

      return {
        ...demanda,
        prioridadeAtendimento: novaPrioridadeAtendimento,
        prazo: novoPrazo,
        prazoDiasUteis: novoSla,
        prazoManual: preservarPrazoManual,
        motivoAlteracaoPrioridade: motivoFinal,
        historico: [historico, ...(demanda.historico || [])],
      }
    })

    return true
  }

  // ==========================================================
  // ALTERAR PRAZO MANUALMENTE
  // ==========================================================

  function alterarPrazoManual(
    id: number,
    novoPrazo: string,
    motivo: string
  ) {
    if (
      sessao?.perfil !==
      'Gestor/Administrador'
    ) {
      return
    }

    if (
      !novoPrazo ||
      !motivo.trim()
    ) {
      window.alert(
        'Informe o novo prazo e o motivo da alteração.'
      )

      return
    }

    if (
      novoPrazo < dataLocalISO()
    ) {
      window.alert(
        'O novo prazo não pode ser anterior à data atual.'
      )
      return
    }

    const demandaPrazo =
      demandas.find(
        (item) => item.id === id
      )

    if (
      demandaPrazo?.status === 'Concluída' ||
      demandaPrazo?.status === 'Cancelada'
    ) {
      window.alert(
        'Demandas concluídas ou canceladas não podem ter o prazo alterado. Reabra a demanda antes, quando aplicável.'
      )
      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        if (
          demanda.prazo ===
          novoPrazo
        ) {
          return demanda
        }

        const motivoFinal =
          motivo.trim()

        const agora =
          agoraISO()

        const descricao =
          `Prazo alterado de "${demanda.prazo}" para "${novoPrazo}". Motivo: ${motivoFinal}.`

        registrarAlteracao(
          'demanda',
          id,
          'alteracao_prazo',
          descricao,
          nomeUsuarioAtual,
          {
            valorAnterior:
              demanda.prazo,

            valorNovo:
              novoPrazo,

            motivo:
              motivoFinal,
          }
        )

        return {
          ...demanda,

          prazo:
            novoPrazo,

          prazoManual:
            true,

          motivoPrazoManual:
            motivoFinal,

          historico: [
            {
              id:
                Date.now(),

              tipo:
                'prazo',

              titulo:
                'Prazo alterado manualmente',

              descricao,

              data:
                agora,

              usuario:
                nomeUsuarioAtual,

              referenciaId:
                id,

              valorAnterior:
                demanda.prazo,

              valorNovo:
                novoPrazo,

              motivo:
                motivoFinal,
            },

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // REABRIR DEMANDA
  // ==========================================================

  function reabrirDemanda(
    id: number,
    motivo: string
  ) {
    if (
      sessao?.perfil !==
      'Gestor/Administrador'
    ) {
      return
    }

    if (
      !motivo.trim()
    ) {
      window.alert(
        'Informe obrigatoriamente o motivo da reabertura.'
      )

      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        if (
          demanda.status !==
          'Concluída'
        ) {
          return demanda
        }

        const responsavelAtual =
          demanda.responsavel?.trim() || ''

        if (
          !responsavelAtual ||
          !analistasAtivos.some(
            (usuario) => usuario.nome === responsavelAtual
          )
        ) {
          window.alert(
            'A demanda precisa ter um Responsável ativo definido para ser reaberta.'
          )
          return demanda
        }

        const agora =
          agoraISO()

        const motivoFinal =
          motivo.trim()

        const historico:
          Historico = {
          id:
            Date.now(),

          tipo:
            'reabertura',

          titulo:
            'Demanda reaberta',

          descricao:
            `A demanda foi reaberta. Motivo: ${motivoFinal}.`,

          data:
            agora,

          usuario:
            nomeUsuarioAtual,

          referenciaId:
            id,

          valorAnterior:
            'Concluída',

          valorNovo:
            'Em Atendimento',

          motivo:
            motivoFinal,
        }

        registrarAlteracao(
          'demanda',
          id,
          'reabertura',
          historico.descricao,
          nomeUsuarioAtual,
          {
            valorAnterior:
              'Concluída',

            valorNovo:
              'Em Atendimento',

            motivo:
              motivoFinal,
          }
        )

        criarNotificacao({
          tipo:
            'alerta',

          titulo:
            'Demanda reaberta',

          descricao:
            `DEM-${String(id).padStart(5, '0')} foi reaberta por ${nomeUsuarioAtual}.`,

          demandaId:
            id,

          prioridade:
            demanda.prioridade,
        })

        return {
          ...demanda,

          status:
            'Em Atendimento',

          dataReabertura:
            agora,

          usuarioReabertura:
            nomeUsuarioAtual,

          dataConclusao:
            undefined,

          usuarioConclusao:
            undefined,

          motivoReabertura:
            motivoFinal,

          historico: [
            historico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // CANCELAR DEMANDA
  //
  // SOMENTE GESTOR.
  // MOTIVO OBRIGATÓRIO.
  // ==========================================================

  function cancelarDemanda(
    id: number,
    motivo: string
  ) {
    if (
      sessao?.perfil !==
      'Gestor/Administrador'
    ) {
      return
    }

    const motivoFinal =
      motivo.trim()

    if (!motivoFinal) {
      window.alert(
        'Informe obrigatoriamente o motivo do cancelamento.'
      )

      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        if (
          demanda.status ===
            'Concluída' ||
          demanda.status ===
            'Cancelada'
        ) {
          return demanda
        }

        const agora =
          agoraISO()

        const statusAnterior =
          demanda.status

        let periodosPendencia =
          [
            ...(demanda.periodosPendencia || []),
          ]

        if (statusAnterior === 'Com Pendências') {
          const ultimo =
            periodosPendencia[
              periodosPendencia.length - 1
            ]

          if (ultimo && !ultimo.fim) {
            periodosPendencia[
              periodosPendencia.length - 1
            ] = {
              ...ultimo,
              fim: agora,
            }
          }
        }

        const descricao =
          `Demanda cancelada. Status anterior: "${statusAnterior}". Motivo: ${motivoFinal}.`

        const historico:
          Historico = {
          id:
            Date.now(),

          tipo:
            'cancelamento',

          titulo:
            'Demanda cancelada',

          descricao,

          data:
            agora,

          usuario:
            nomeUsuarioAtual,

          referenciaId:
            id,

          valorAnterior:
            statusAnterior,

          valorNovo:
            'Cancelada',

          motivo:
            motivoFinal,
        }

        registrarAlteracao(
          'demanda',
          id,
          'cancelamento',
          descricao,
          nomeUsuarioAtual,
          {
            valorAnterior:
              statusAnterior,

            valorNovo:
              'Cancelada',

            motivo:
              motivoFinal,
          }
        )

        criarNotificacao({
          tipo:
            'alerta',

          titulo:
            'Demanda cancelada',

          descricao:
            `DEM-${String(id).padStart(5, '0')} foi cancelada por ${nomeUsuarioAtual}.`,

          demandaId:
            id,

          prioridade:
            demanda.prioridade,
        })

        return {
          ...demanda,

          status:
            'Cancelada',

          motivoCancelamento:
            motivoFinal,

          periodosPendencia,

          historico: [
            historico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // ALTERAR STATUS
  // ==========================================================

  function alterarStatus(
    id: number,
    novoStatus: string,
    motivo?: string
  ) {
    if (
      !STATUS_OFICIAIS.includes(
        novoStatus
      )
    ) {
      return
    }

    const demandaAtual =
      demandas.find(
        (item) => item.id === id
      )

    if (!demandaAtual) {
      return
    }

    const usuarioEhGestor =
      ehGestor(sessao)

    if (
      !usuarioEhGestor &&
      demandaAtual.responsavel !== nomeUsuarioAtual
    ) {
      window.alert(
        'Você só pode alterar o status de demandas atribuídas a você.'
      )
      return
    }

    if (
      demandaAtual.status === novoStatus
    ) {
      return
    }

    if (
      !transicaoPermitida(
        demandaAtual.status,
        novoStatus
      )
    ) {
      window.alert(
        `Não é permitido alterar o status de "${demandaAtual.status}" para "${novoStatus}". Utilize a ação específica disponível no fluxo.`
      )
      return
    }

    if (
      demandaAtual.status === 'Nova' &&
      novoStatus === 'Aguardando' &&
      !usuarioEhGestor
    ) {
      window.alert(
        'Somente o Gestor pode colocar uma demanda Nova em Aguardando.'
      )
      return
    }

    if (
      novoStatus ===
        'Com Pendências' &&
      !motivo?.trim()
    ) {
      window.alert(
        'O motivo da pendência é obrigatório.'
      )

      return
    }

    if (
      novoStatus ===
        'Concluída' &&
      !motivo?.trim()
    ) {
      window.alert(
        'O comentário de conclusão é obrigatório.'
      )

      return
    }

    if (
      novoStatus ===
        'Em Atendimento' &&
      !demandaAtual.responsavel?.trim()
    ) {
      window.alert(
        'Defina um Responsável antes de colocar a demanda Em Atendimento.'
      )
      return
    }

    if (
      novoStatus ===
        'Em Atendimento' &&
      !analistasAtivos.some(
        (usuario) =>
          usuario.nome ===
          demandaAtual.responsavel
      )
    ) {
      window.alert(
        'O Responsável precisa estar ativo e cadastrado no sistema.'
      )
      return
    }

    if (
      novoStatus ===
        'Cancelada'
    ) {
      cancelarDemanda(
        id,
        motivo || ''
      )

      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        if (
          demanda.status ===
          novoStatus
        ) {
          return demanda
        }

        const agora =
          agoraISO()

        const statusAnterior =
          demanda.status

        let periodosPendencia =
          [
            ...(demanda.periodosPendencia ||
              []),
          ]

        if (
          novoStatus ===
          'Com Pendências'
        ) {
          periodosPendencia = [
            ...periodosPendencia,

            {
              inicio:
                agora,

              motivo:
                motivo?.trim() ||
                'Pendência registrada.',
            },
          ]
        }

        if (
          novoStatus ===
            'Concluída' &&
          statusAnterior ===
            'Com Pendências'
        ) {
          const ultimo =
            periodosPendencia[
              periodosPendencia.length - 1
            ]

          if (
            ultimo &&
            !ultimo.fim
          ) {
            periodosPendencia[
              periodosPendencia.length - 1
            ] = {
              ...ultimo,
              fim:
                agora,
            }
          }
        }

        if (
          novoStatus ===
            'Em Atendimento' &&
          statusAnterior ===
            'Com Pendências'
        ) {
          const ultimo =
            periodosPendencia[
              periodosPendencia.length -
                1
            ]

          if (
            ultimo &&
            !ultimo.fim
          ) {
            periodosPendencia[
              periodosPendencia.length -
                1
            ] = {
              ...ultimo,

              fim:
                agora,
            }
          }
        }

        let titulo =
          'Status alterado'

        if (
          novoStatus ===
          'Concluída'
        ) {
          titulo =
            'Demanda concluída'
        } else if (
          novoStatus ===
          'Com Pendências'
        ) {
          titulo =
            'Demanda colocada em Com Pendências'
        } else if (
          novoStatus ===
            'Em Atendimento' &&
          statusAnterior ===
            'Com Pendências'
        ) {
          titulo =
            'Atendimento retomado'
        }

        let descricao =
          `Status alterado de "${statusAnterior}" para "${novoStatus}".`

        if (
          novoStatus ===
          'Com Pendências'
        ) {
          descricao =
            `A demanda foi colocada em "Com Pendências". Motivo: ${motivo?.trim() || 'Não informado'}.`
        }

        if (
          novoStatus ===
          'Concluída'
        ) {
          descricao =
            `A demanda foi concluída. Comentário de conclusão: ${motivo?.trim()}.`
        }

        const historico:
          Historico = {
          id:
            Date.now() +
            Math.floor(
              Math.random() *
                1000
            ),

          tipo:
            'status',

          titulo,

          descricao,

          data:
            agora,

          usuario:
            nomeUsuarioAtual,

          referenciaId:
            id,

          valorAnterior:
            statusAnterior,

          valorNovo:
            novoStatus,

          motivo:
            motivo?.trim(),
        }

        registrarAlteracao(
          'demanda',
          id,
          'alteracao_status',
          descricao,
          nomeUsuarioAtual,
          {
            valorAnterior:
              statusAnterior,

            valorNovo:
              novoStatus,

            motivo:
              motivo?.trim(),
          }
        )

        if (
          novoStatus ===
          'Com Pendências'
        ) {
          criarNotificacao({
            tipo:
              'alerta',

            titulo:
              'Demanda com pendência',

            descricao:
              `DEM-${String(id).padStart(5, '0')} foi colocada em Com Pendências.`,

            demandaId:
              id,

            prioridade:
              demanda.prioridade,
          })
        }

        if (
          novoStatus ===
          'Concluída'
        ) {
          criarNotificacao({
            tipo:
              'informativo',

            titulo:
              'Demanda concluída',

            descricao:
              `DEM-${String(id).padStart(5, '0')} foi concluída por ${nomeUsuarioAtual}.`,

            demandaId:
              id,

            prioridade:
              demanda.prioridade,
          })
        }

        return {
          ...demanda,

          status:
            novoStatus,

          responsavel:
            statusAnterior === 'Em Atendimento' &&
            novoStatus === 'Aguardando'
              ? ''
              : demanda.responsavel,

          dataConclusao:
            novoStatus ===
            'Concluída'
              ? agora
              : demanda.dataConclusao,

          usuarioConclusao:
            novoStatus ===
            'Concluída'
              ? nomeUsuarioAtual
              : demanda.usuarioConclusao,

          periodosPendencia,

          historico: [
            historico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // ALTERAÇÃO DE STATUS EM MASSA
  //
  // NÃO PERMITE:
  // - Conclusão
  // - Cancelamento
  //
  // Porque ambos exigem dados obrigatórios.
  // ==========================================================

  function alterarStatusEmMassa(
    ids: number[],
    novoStatus: string
  ) {
    if (
      !ids.length ||
      !novoStatus
    ) {
      return
    }

    if (
      !ehGestor(sessao)
    ) {
      window.alert(
        'A alteração de status em massa está disponível somente para o Gestor.'
      )
      return
    }

    if (
      novoStatus ===
        'Com Pendências' ||
      novoStatus ===
        'Concluída' ||
      novoStatus ===
        'Cancelada'
    ) {
      window.alert(
        'Com Pendências, Conclusão e Cancelamento devem ser realizados pela tela de detalhe, com os dados obrigatórios.'
      )

      return
    }

    if (
      !STATUS_OFICIAIS.includes(
        novoStatus
      )
    ) {
      return
    }

    const idsValidos =
      new Set(ids)

    const agora =
      agoraISO()

    let alteradas = 0

    const demandasAtualizadas =
      demandas.map(
        (demanda) => {
          if (
            !idsValidos.has(
              demanda.id
            )
          ) {
            return demanda
          }

          const demandaNormalizada =
            normalizarDemanda(
              demanda
            )

          if (
            demandaNormalizada.status ===
            novoStatus
          ) {
            return demandaNormalizada
          }

          if (
            !transicaoPermitida(
              demandaNormalizada.status,
              novoStatus
            )
          ) {
            return demandaNormalizada
          }

          if (
            novoStatus ===
              'Em Atendimento' &&
            !demandaNormalizada.responsavel?.trim()
          ) {
            return demandaNormalizada
          }

          if (
            novoStatus ===
              'Em Atendimento' &&
            !analistasAtivos.some(
              (usuario) =>
                usuario.nome ===
                demandaNormalizada.responsavel
            )
          ) {
            return demandaNormalizada
          }

          let periodosPendencia = [
            ...(demandaNormalizada.periodosPendencia || []),
          ]

          if (
            novoStatus === 'Em Atendimento' &&
            demandaNormalizada.status === 'Com Pendências'
          ) {
            const ultimo =
              periodosPendencia[
                periodosPendencia.length - 1
              ]

            if (ultimo && !ultimo.fim) {
              periodosPendencia[
                periodosPendencia.length - 1
              ] = {
                ...ultimo,
                fim: agora,
              }
            }
          }

          alteradas += 1

          const historico:
            Historico = {
            id:
              Date.now() +
              Math.floor(
                Math.random() *
                  100000
              ),

            tipo:
              'status',

            titulo:
              'Status alterado em massa',

            descricao:
              `Status alterado de "${demandaNormalizada.status}" para "${novoStatus}" por ação em massa.`,

            data:
              agora,

            usuario:
              nomeUsuarioAtual,

            referenciaId:
              demandaNormalizada.id,

            valorAnterior:
              demandaNormalizada.status,

            valorNovo:
              novoStatus,
          }

          registrarAlteracao(
            'demanda',
            demandaNormalizada.id,
            'alteracao_status_massa',
            historico.descricao,
            nomeUsuarioAtual,
            {
              valorAnterior:
                demandaNormalizada.status,

              valorNovo:
                novoStatus,
            }
          )

          return {
            ...demandaNormalizada,

            status:
              novoStatus,

            responsavel:
              demandaNormalizada.status === 'Em Atendimento' &&
              novoStatus === 'Aguardando'
                ? ''
                : demandaNormalizada.responsavel,

            periodosPendencia,

            historico: [
              historico,

              ...(demandaNormalizada.historico ||
                []),
            ],
          }
        }
      )

    if (
      alteradas === 0
    ) {
      window.alert(
        'Nenhuma das demandas selecionadas pode receber esse status dentro das regras atuais do fluxo.'
      )
      return
    }

    salvarDemandas(
      demandasAtualizadas
    )
  }

  // ==========================================================
  // ALTERAR RESPONSÁVEL
  // ==========================================================

  function alterarResponsavel(
    id: number,
    novoResponsavel: string
  ) {
    if (!ehGestor(sessao)) {
      window.alert(
        'Somente o Gestor pode distribuir ou redistribuir demandas.'
      )
      return
    }

    const nomeNovo =
      novoResponsavel.trim()

    const analistaValido =
      !nomeNovo ||
      analistasAtivos.some(
        (usuario) =>
          usuario.nome ===
          nomeNovo
      )

    if (
      !analistaValido
    ) {
      window.alert(
        'Selecione um Responsável ativo cadastrado no sistema.'
      )

      return
    }

    const demandaAtual =
      demandas.find(
        (item) => item.id === id
      )

    if (!demandaAtual) {
      return
    }

    if (
      demandaAtual.status === 'Cancelada'
    ) {
      window.alert(
        'Demandas canceladas não podem ser redistribuídas.'
      )
      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        if (
          demanda.responsavel ===
          nomeNovo
        ) {
          return demanda
        }

        const anterior =
          demanda.responsavel ||
          'Sem Responsável'

        const novo =
          nomeNovo ||
          'Sem Responsável'

        let statusNovo =
          demanda.status

        if (demanda.status === 'Aguardando') {
          statusNovo =
            nomeNovo
              ? 'Em Atendimento'
              : 'Aguardando'
        } else if (
          demanda.status === 'Em Atendimento'
        ) {
          statusNovo =
            nomeNovo
              ? 'Em Atendimento'
              : 'Aguardando'
        } else if (
          demanda.status === 'Nova'
        ) {
          statusNovo =
            nomeNovo
              ? 'Em Atendimento'
              : 'Nova'
        } else if (
          demanda.status === 'Com Pendências'
        ) {
          if (!nomeNovo) {
            window.alert(
              'Uma demanda em Com Pendências precisa permanecer com um Responsável definido.'
            )
            return demanda
          }

          statusNovo =
            'Com Pendências'
        } else if (
          demanda.status === 'Concluída'
        ) {
          // Permite que o Gestor defina um Analista antes da reabertura,
          // sem alterar o estado final da demanda.
          statusNovo =
            'Concluída'
        }

        const historico =
          criarHistorico(
            'redistribuicao',
            'Responsável alterado',
            `Responsável alterado de "${anterior}" para "${novo}".`,
            id,
            {
              valorAnterior:
                anterior,

              valorNovo:
                novo,
            }
          )

        registrarAlteracao(
          'demanda',
          id,
          'redistribuicao',
          `Demanda redistribuída de "${anterior}" para "${novo}".`,
          nomeUsuarioAtual,
          {
            valorAnterior:
              anterior,

            valorNovo:
              novo,
          }
        )

        if (
          nomeNovo &&
          demanda.status !== 'Concluída'
        ) {
          criarNotificacao({
            tipo:
              'informativo',

            titulo:
              'Demanda atribuída',

            descricao:
              `A demanda DEM-${String(id).padStart(5, '0')} foi atribuída para ${nomeNovo}.`,

            demandaId:
              id,

            prioridade:
              demanda.prioridade,
          })
        }

        return {
          ...demanda,

          responsavel:
            nomeNovo,

          status:
            statusNovo,

          historico: [
            historico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // ADICIONAR COMENTÁRIO
  // ==========================================================

  function adicionarComentario(
    id: number,
    texto: string
  ) {
    const textoLimpo =
      texto.trim()

    if (
      !textoLimpo
    ) {
      return
    }

    const demandaAtual =
      demandas.find(
        (item) => item.id === id
      )

    if (!demandaAtual) {
      return
    }

    if (
      !ehGestor(sessao) &&
      demandaAtual.responsavel?.trim() !== nomeUsuarioAtual
    ) {
      window.alert(
        'Você só pode comentar em demandas atribuídas a você.'
      )
      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        const novoComentario:
          Comentario = {
          id:
            Date.now() +
            Math.floor(
              Math.random() *
                1000
            ),

          texto:
            textoLimpo,

          usuario:
            nomeUsuarioAtual,

          data:
            agoraISO(),
        }

        const novoHistorico =
          criarHistorico(
            'comentario',
            'Comentário adicionado',
            'Foi adicionado um novo comentário à demanda.',
            novoComentario.id
          )

        registrarAlteracao(
          'demanda',
          id,
          'comentario',
          'Novo comentário adicionado à demanda.',
          nomeUsuarioAtual
        )

        return {
          ...demanda,

          comentarios: [
            ...(demanda.comentarios ||
              []),

            novoComentario,
          ],

          historico: [
            novoHistorico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // ADICIONAR ARQUIVO
  // ==========================================================

  function adicionarArquivo(
    id: number,
    arquivo: Arquivo
  ) {
    const demandaAtual =
      demandas.find(
        (item) => item.id === id
      )

    if (!demandaAtual) {
      return
    }

    if (
      !ehGestor(sessao) &&
      demandaAtual.responsavel?.trim() !== nomeUsuarioAtual
    ) {
      window.alert(
        'Você só pode anexar arquivos em demandas atribuídas a você.'
      )
      return
    }

    atualizarDemanda(
      id,
      (demanda) => {
        const novoHistorico =
          criarHistorico(
            'arquivo',
            'Arquivo anexado',
            `O arquivo "${arquivo.nome}" foi anexado à demanda.`,
            arquivo.id
          )

        registrarAlteracao(
          'demanda',
          id,
          'anexo',
          `Arquivo "${arquivo.nome}" anexado à demanda.`,
          nomeUsuarioAtual
        )

        return {
          ...demanda,

          arquivos: [
            ...(demanda.arquivos ||
              []),

            arquivo,
          ],

          historico: [
            novoHistorico,

            ...(demanda.historico ||
              []),
          ],
        }
      }
    )
  }

  // ==========================================================
  // ABRIR DETALHE
  // ==========================================================

  function abrirDetalhe(
    demanda: Demanda
  ) {
    setDemandaSelecionada(
      normalizarDemanda(
        demanda
      )
    )

    setPagina(
      'detalhe-demanda'
    )
  }

  // ==========================================================
  // VOLTAR A PARTIR DO DETALHE
  // ==========================================================

  function voltarParaDemandas() {
    setDemandaSelecionada(
      null
    )

    setPagina(
      ehPerfilOperacional(sessao?.perfil)
        ? 'dashboard-analista'
        : 'todas-demandas'
    )
  }

  // ==========================================================
  // ABRIR FERIADOS
  // ==========================================================

  function abrirFeriados() {
    if (!ehGestor(sessao)) return
    setPagina('feriados')
  }

  // ==========================================================
  // NAVEGAÇÃO DO MENU PRINCIPAL
  // ==========================================================

  function abrirNovaDemanda() {
    if (!ehGestor(sessao)) return
    setPagina('nova-demanda')
  }

  function abrirClientes() {
    if (!ehGestor(sessao)) return
    setPagina('clientes')
  }

  function abrirResponsaveis() {
    if (!ehGestor(sessao)) return
    setPagina('responsaveis')
  }

  function abrirRelatorios() {
    if (!ehGestor(sessao)) return
    setPagina('relatorios')
  }

  // ==========================================================
  // CONFIGURAÇÕES
  // ==========================================================

  function abrirConfiguracoes() {
    if (
      sessao?.perfil !== 'Gestor/Administrador' &&
      String(sessao?.perfil) !== 'Gestor'
    ) {
      return
    }

    setPagina('configuracoes')
  }

  function abrirAdministracao() {
    if (
      sessao?.perfil !== 'Gestor/Administrador' &&
      String(sessao?.perfil) !== 'Gestor'
    ) {
      return
    }

    setPagina('administracao')
  }

  // ==========================================================
  // PRIMEIRO ACESSO / TROCA OBRIGATÓRIA DE SENHA
  // ==========================================================

  if (usuarioTrocaSenha) {
    return (
      <TrocarSenha
        usuario={usuarioTrocaSenha}
        onSalvar={salvarNovaSenha}
        onSair={realizarLogout}
      />
    )
  }

  // ==========================================================
  // AUTENTICAÇÃO
  // ==========================================================

  if (
    !sessao ||
    pagina === 'login'
  ) {
    return (
      <Login
        onLogin={
          realizarLogin
        }
      />
    )
  }

  // ==========================================================
  // DASHBOARD DO ANALISTA
  // ==========================================================

  if (
    ehPerfilOperacional(sessao.perfil) &&
    pagina === 'dashboard-analista'
  ) {
    return (
      <DashboardAnalista
        usuario={usuarioAtual!}
        demandas={demandas}
        onDashboard={() => setPagina('dashboard-analista')}
        onMinhasDemandas={() => setPagina('minhas-demandas')}
        onConfiguracoes={() => setPagina('configuracoes-analista')}
        onAbrirDetalhe={abrirDetalhe}
        onSair={realizarLogout}
      />
    )
  }

  // ==========================================================
  // MINHAS DEMANDAS
  // ==========================================================

  if (
    pagina ===
    'minhas-demandas'
  ) {
    return (
      <MinhasDemandas
        usuario={
          usuarioAtual!
        }

        demandas={
          demandas
        }

        onVoltar={
          realizarLogout
        }

        onDashboard={() =>
          setPagina('dashboard-analista')
        }

        onConfiguracoes={() =>
          setPagina('configuracoes-analista')
        }

        onAbrirDetalhe={
          abrirDetalhe
        }

        onAlterarStatus={
          alterarStatus
        }

        onAdicionarComentario={
          adicionarComentario
        }
      />
    )
  }

  // ==========================================================
  // CONFIGURAÇÕES DO ANALISTA
  // ==========================================================

  if (
    ehPerfilOperacional(sessao.perfil) &&
    pagina === 'configuracoes-analista'
  ) {
    return (
      <ConfiguracoesAnalista
        usuario={usuarioAtual!}
        onDashboard={() => setPagina('dashboard-analista')}
        onMinhasDemandas={() => setPagina('minhas-demandas')}
        onConfiguracoes={() => setPagina('configuracoes-analista')}
        onSair={realizarLogout}
      />
    )
  }

  // ==========================================================
  // CONFIGURAÇÕES
  // ==========================================================

  if (
    pagina ===
      'configuracoes' &&
    (
      sessao.perfil ===
        'Gestor/Administrador' ||
      String(sessao.perfil) ===
        'Gestor'
    )
  ) {
    return (
      <Configuracoes
        usuarioAtual={usuarioAtual!}
        onVoltar={() => setPagina('dashboard')}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={abrirNovaDemanda}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onAdministracao={abrirAdministracao}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // ADMINISTRAÇÃO
  // ==========================================================

  if (
    pagina ===
      'administracao' &&
    (
      sessao.perfil ===
        'Gestor/Administrador' ||
      String(sessao.perfil) ===
        'Gestor'
    )
  ) {
    return (
      <Administracao
        usuarioAtual={usuarioAtual!}

        onVoltar={() =>
          setPagina('dashboard')
        }

        onVoltarConfiguracoes={() =>
          setPagina('configuracoes')
        }

        onFeriados={() =>
          setPagina('feriados')
        }

        onDashboard={() =>
          setPagina('dashboard')
        }

        onTodasDemandas={() =>
          setPagina('todas-demandas')
        }

        onNovaDemanda={abrirNovaDemanda}

        onClientes={abrirClientes}

        onResponsaveis={abrirResponsaveis}

        onRelatorios={abrirRelatorios}

        onConfiguracoes={abrirConfiguracoes}

        onSair={realizarLogout}
      />
    )
  }

  // ==========================================================
  // FERIADOS
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'feriados') {
    return (
      <Feriados
        onVoltar={() =>
          setPagina(
            'dashboard'
          )
        }

        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={abrirNovaDemanda}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // TODAS AS DEMANDAS
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'todas-demandas') {
    return (
      <TodasDemandas
        demandas={
          demandas
        }

        onVoltar={() =>
          setPagina(
            'dashboard'
          )
        }

        onNovaDemanda={() =>
          setPagina(
            'nova-demanda'
          )
        }

        onAlterarStatus={
          alterarStatus
        }

        onAlterarStatusEmMassa={
          alterarStatusEmMassa
        }

        onAbrirDetalhe={
          abrirDetalhe
        }

        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // NOVA DEMANDA
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'nova-demanda') {
    return (
      <NovaDemanda
        clientes={
          clientesCadastrados
        }

        sistemas={
          sistemasCadastrados
        }

        tipos={
          tiposCadastrados
        }

        analistas={
          analistasAtivos
        }

        onVoltar={() =>
          setPagina(
            'todas-demandas'
          )
        }

        onSalvar={
          salvarDemanda
        }

        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={abrirNovaDemanda}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // DETALHE DA DEMANDA
  // ==========================================================

  if (
    pagina ===
      'detalhe-demanda' &&
    demandaSelecionada
  ) {
    return (
      <DetalheDemandaPage
        demanda={
          demandaSelecionada
        }

        onVoltar={
          voltarParaDemandas
        }

        onAlterarStatus={
          alterarStatus
        }

        onAlterarResponsavel={
          alterarResponsavel
        }

        onAdicionarComentario={
          adicionarComentario
        }

        onAdicionarArquivo={
          adicionarArquivo
        }

        nomeUsuario={nomeUsuarioAtual}
        perfilUsuarioGlobal={sessao.perfil || 'Gestor/Administrador'}

        onMinhasDemandas={
          ehPerfilOperacional(sessao.perfil)
            ? () => setPagina('minhas-demandas')
            : undefined
        }

        onDashboard={() =>
          setPagina(
            ehPerfilOperacional(sessao.perfil)
              ? 'dashboard-analista'
              : 'dashboard'
          )
        }

        onTodasDemandas={() =>
          setPagina(
            'todas-demandas'
          )
        }

        onNovaDemanda={
          abrirNovaDemanda
        }

        onClientes={
          abrirClientes
        }

        onResponsaveis={
          abrirResponsaveis
        }

        onFeriados={
          abrirFeriados
        }

        onRelatorios={
          abrirRelatorios
        }

        onConfiguracoes={
          ehPerfilOperacional(sessao.perfil)
            ? () => setPagina('configuracoes-analista')
            : abrirConfiguracoes
        }

        onLogout={
          realizarLogout
        }

        perfilUsuario={
          sessao.perfil
        }

        analistas={
          analistasAtivos
        }

        onAlterarPrioridade={
          alterarPrioridade
        }

        onAlterarPrioridadeAtendimento={
          alterarPrioridadeAtendimento
        }

        onAlterarPrazoManual={
          alterarPrazoManual
        }

        onReabrirDemanda={
          reabrirDemanda
        }

        onCancelarDemanda={
          cancelarDemanda
        }
      />
    )
  }

  // ==========================================================
  // CLIENTES
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'clientes') {
    return (
      <Clientes
        onVoltar={() => setPagina('dashboard')}
        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={() => setPagina('nova-demanda')}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // RESPONSÁVEIS / ANALISTAS
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'responsaveis') {
    return (
      <Responsaveis
        onVoltar={() => setPagina('dashboard')}
        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={() => setPagina('nova-demanda')}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // RELATÓRIOS
  // ==========================================================

  if (ehGestor(sessao) && pagina === 'relatorios') {
    return (
      <Relatorios
        onVoltar={() => setPagina('dashboard')}
        nomeUsuario={nomeUsuarioAtual}
        perfilUsuario={sessao.perfil || 'Gestor/Administrador'}
        onDashboard={() => setPagina('dashboard')}
        onTodasDemandas={() => setPagina('todas-demandas')}
        onNovaDemanda={() => setPagina('nova-demanda')}
        onClientes={abrirClientes}
        onResponsaveis={abrirResponsaveis}
        onFeriados={abrirFeriados}
        onRelatorios={abrirRelatorios}
        onConfiguracoes={abrirConfiguracoes}
        onLogout={realizarLogout}
      />
    )
  }

  // ==========================================================
  // DASHBOARD
  // ==========================================================

  if (ehPerfilOperacional(sessao.perfil)) {
    return (
      <DashboardAnalista
        usuario={usuarioAtual!}
        demandas={demandas}
        onDashboard={() => setPagina('dashboard-analista')}
        onMinhasDemandas={() => setPagina('minhas-demandas')}
        onConfiguracoes={() => setPagina('configuracoes-analista')}
        onAbrirDetalhe={abrirDetalhe}
        onSair={realizarLogout}
      />
    )
  }

  return (
    <div
      style={{
        position:
          'relative',

        minHeight:
          '100vh',
      }}
    >
      <Dashboard
        usuarioAtual={usuarioAtual!}
        onLogout={
          realizarLogout
        }

        onTodasDemandas={() =>
          setPagina(
            'todas-demandas'
          )
        }

        onNovaDemanda={
          abrirNovaDemanda
        }

        onClientes={
          abrirClientes
        }

        onResponsaveis={
          abrirResponsaveis
        }

        onFeriados={
          abrirFeriados
        }

        onRelatorios={
          abrirRelatorios
        }

        onConfiguracoes={abrirConfiguracoes}
      />

    </div>
  )
}

export default App
