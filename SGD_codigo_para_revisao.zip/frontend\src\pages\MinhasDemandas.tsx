import { useMemo, useState, type FormEvent } from 'react'

import type { Demanda, Usuario } from '../types'
import { estaAtrasada as estaAtrasadaSLA, estaProximaDoVencimento as estaProximaDoVencimentoSLA } from '../sla'

import { carregarUsuarios, salvarUsuarios } from '../services/storage'

import { registrarAlteracao } from '../services/auditoria'

import { mostrarToast } from '../services/toast'

import MenuPrincipal from '../components/MenuPrincipal'

import './MinhasDemandas.css'

type Props = {

  usuario: Usuario

  demandas: Demanda[]

  onVoltar: () => void

  onDashboard?: () => void

  onConfiguracoes?: () => void

  onAbrirDetalhe: (demanda: Demanda) => void

  onAlterarStatus: (id: number, novoStatus: string, motivo?: string) => void

  onAdicionarComentario: (id: number, texto: string) => void

}

type UsuarioSeguranca = Usuario & {

  senhaHash?: string

  exigirTrocaSenha?: boolean

}

const MINIMO_SENHA = 6

const STATUS = ['Todos', 'Aguardando', 'Em Atendimento', 'Com Pendências', 'Concluída', 'Cancelada']

const PRIORIDADES = ['Todas', 'Crítica', 'Alta', 'Média', 'Baixa']
const PRIORIDADES_ATENDIMENTO = ['Todas', 'P1 — Imediata', 'P2 — Urgente', 'P3 — Normal', 'P4 — Planejada']

async function hashSenha(senha: string): Promise<string> {

  const bytes = new TextEncoder().encode(senha)

  const digest = await window.crypto.subtle.digest('SHA-256', bytes)

  return Array.from(new Uint8Array(digest))

    .map((byte) => byte.toString(16).padStart(2, '0'))

    .join('')

}

function converterData(data: string): Date | null {

  if (!data) return null

  const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(data)

  if (match) {

    const [, dia, mes, ano] = match

    const resultado = new Date(Number(ano), Number(mes) - 1, Number(dia))

    resultado.setHours(0, 0, 0, 0)

    return resultado

  }

  const resultado = new Date(data)

  if (Number.isNaN(resultado.getTime())) return null

  resultado.setHours(0, 0, 0, 0)

  return resultado

}

function formatarData(data: string): string {

  const valor = converterData(data)

  if (!valor) return data || '—'

  return valor.toLocaleDateString('pt-BR')

}

function estaAtrasada(demanda: Demanda): boolean {
  return estaAtrasadaSLA(demanda)

}

function estaProxima(demanda: Demanda): boolean {
  return estaProximaDoVencimentoSLA(demanda, 7)

}

function classeStatus(status: string): string {

  switch (status) {

    case 'Nova':

      return 'md-status-nova'

    case 'Aguardando':

      return 'md-status-aguardando'

    case 'Em Atendimento':

      return 'md-status-em-atendimento'

    case 'Com Pendências':

      return 'md-status-com-pendencias'

    case 'Concluída':

      return 'md-status-concluida'

    case 'Cancelada':

      return 'md-status-cancelada'

    default:

      return 'md-status'

  }

}

function classePrioridadeAtendimento(prioridadeAtendimento: string): string {

  const prioridade = prioridadeAtendimento.trim().toUpperCase()

  if (prioridade.startsWith('P1')) return 'md-prioridade-atendimento md-prioridade-p1'

  if (prioridade.startsWith('P2')) return 'md-prioridade-atendimento md-prioridade-p2'

  if (prioridade.startsWith('P3')) return 'md-prioridade-atendimento md-prioridade-p3'

  if (prioridade.startsWith('P4')) return 'md-prioridade-atendimento md-prioridade-p4'

  return 'md-prioridade-atendimento'

}

function normalizarCriticidade(valor: string): string {

  return String(valor || '')

    .trim()

    .normalize('NFD')

    .replace(/[\u0300-\u036f]/g, '')

    .toLowerCase()

}

function classeLinhaCriticidade(criticidade: string): string {

  const valor = normalizarCriticidade(criticidade)

  return valor === 'critica' || valor === 'urgente' ? 'md-row-critica' : ''

}

function classeCriticidade(criticidade: string): string {

  switch (normalizarCriticidade(criticidade)) {

    case 'critica':

    case 'urgente':

      return 'md-criticidade-critica'

    case 'alta':

      return 'md-criticidade-alta'

    case 'media':

      return 'md-criticidade-media'

    case 'baixa':

      return 'md-criticidade-baixa'

    default:

      return 'md-criticidade-indefinida'

  }

}

export default function MinhasDemandas({

  usuario,

  demandas,

  onVoltar,

  onDashboard,

  onConfiguracoes,

  onAbrirDetalhe,

  onAlterarStatus,

}: Props) {

  const [pesquisa, setPesquisa] = useState('')

  const [statusFiltro, setStatusFiltro] = useState('Todos')

  const [prioridadeFiltro, setPrioridadeFiltro] = useState('Todas')
  const [prioridadeAtendimentoFiltro, setPrioridadeAtendimentoFiltro] = useState('Todas')

  const [situacaoFiltro, setSituacaoFiltro] = useState('Todos')

  const [contaAberta, setContaAberta] = useState(false)

  const [novoEmail, setNovoEmail] = useState(usuario.email || '')

  const [novaSenha, setNovaSenha] = useState('')

  const [confirmacaoSenha, setConfirmacaoSenha] = useState('')

  const [mostrarNovaSenha, setMostrarNovaSenha] = useState(false)

  const [mostrarConfirmacao, setMostrarConfirmacao] = useState(false)

  const [erroConta, setErroConta] = useState('')

  const minhasDemandas = useMemo(

    () => demandas.filter((demanda) => demanda.responsavel?.trim().toLowerCase() === usuario.nome?.trim().toLowerCase()),

    [demandas, usuario.nome],

  )

  const demandasFiltradas = useMemo(() => {

    const termo = pesquisa.trim().toLowerCase()

    return minhasDemandas.filter((demanda) => {

      const correspondePesquisa = !termo ||

        `${demanda.id} ${demanda.titulo} ${demanda.cliente} ${demanda.sistema || ''} ${demanda.descricao} ${demanda.criticidade || demanda.prioridade || ''} ${demanda.prioridadeAtendimento || ''}`

          .toLowerCase()

          .includes(termo)

      const correspondeStatus = statusFiltro === 'Todos' || demanda.status === statusFiltro

      const correspondePrioridade = prioridadeFiltro === 'Todas' || (demanda.criticidade || demanda.prioridade) === prioridadeFiltro

      const correspondePrioridadeAtendimento = prioridadeAtendimentoFiltro === 'Todas' || demanda.prioridadeAtendimento === prioridadeAtendimentoFiltro

      const correspondeSituacao = situacaoFiltro === 'Todos'

        || (situacaoFiltro === 'Abertas' && demanda.status !== 'Concluída' && demanda.status !== 'Cancelada')

        || (situacaoFiltro === 'Concluídas' && demanda.status === 'Concluída')

        || (situacaoFiltro === 'Atrasadas' && estaAtrasada(demanda))

      return correspondePesquisa && correspondeStatus && correspondePrioridade && correspondePrioridadeAtendimento && correspondeSituacao

    })

  }, [minhasDemandas, pesquisa, statusFiltro, prioridadeFiltro, prioridadeAtendimentoFiltro, situacaoFiltro])

  const indicadores = useMemo(() => ({

    total: minhasDemandas.length,

    abertas: minhasDemandas.filter((item) => item.status !== 'Concluída' && item.status !== 'Cancelada').length,

    aguardando: minhasDemandas.filter((item) => item.status === 'Aguardando').length,

    atendimento: minhasDemandas.filter((item) => item.status === 'Em Atendimento').length,

    pendencias: minhasDemandas.filter((item) => item.status === 'Com Pendências').length,

    atrasadas: minhasDemandas.filter(estaAtrasada).length,

    concluidas: minhasDemandas.filter((item) => item.status === 'Concluída').length,

  }), [minhasDemandas])

  function limparFiltros() {

    setPesquisa('')

    setStatusFiltro('Todos')

    setPrioridadeFiltro('Todas')
    setPrioridadeAtendimentoFiltro('Todas')

    setSituacaoFiltro('Todos')

  }

  async function salvarConta(event: FormEvent<HTMLFormElement>) {

    event.preventDefault()

    setErroConta('')

    const email = novoEmail.trim()

    const senha = novaSenha

    if (!email) {

      setErroConta('Informe Um E-mail Válido.')

      return

    }

    if (senha && senha.length < MINIMO_SENHA) {

      setErroConta(`A nova senha deve possuir no mínimo ${MINIMO_SENHA} caracteres.`)

      return

    }

    if (senha && senha !== confirmacaoSenha) {

      setErroConta('A Confirmação Da Senha Não Confere.')

      return

    }

    try {

      const usuarios = carregarUsuarios() as UsuarioSeguranca[]

      const usuarioAtual = usuarios.find((item) => item.id === usuario.id)

      if (!usuarioAtual) {

        setErroConta('Usuário Não Encontrado.')

        return

      }

      const emailEmUso = usuarios.some(

        (item) => item.id !== usuario.id && item.email.toLowerCase() === email.toLowerCase(),

      )

      if (emailEmUso) {

        setErroConta('Este E-mail Já Está Sendo Utilizado Por Outro Usuário.')

        return

      }

      let usuarioAtualizado: UsuarioSeguranca = {

        ...usuarioAtual,

        email,

        atualizadoEm: new Date().toISOString(),

      }

      if (senha) {

        usuarioAtualizado = {

          ...usuarioAtualizado,

          senhaHash: await hashSenha(senha),

          exigirTrocaSenha: false,

        }

      }

      const atualizados = usuarios.map((item) => item.id === usuario.id ? usuarioAtualizado : item)

      salvarUsuarios(atualizados)

      if (usuarioAtual.email !== email) {

        registrarAlteracao(

          'usuario',

          usuario.id,

          'alteracao_email',

          `O Usuário ${usuario.nome} Alterou O Próprio E-mail.`,

          usuario.nome,

          { valorAnterior: usuarioAtual.email, valorNovo: email },

        )

      }

      if (senha) {

        registrarAlteracao(

          'usuario',

          usuario.id,

          'troca_senha',

          `O Usuário ${usuario.nome} Alterou A Própria Senha.`,

          usuario.nome,

        )

      }

      mostrarToast('Dados Da Conta Atualizados Com Sucesso.')

      setNovaSenha('')

      setConfirmacaoSenha('')

      setContaAberta(false)

    } catch {

      setErroConta('Não Foi Possível Salvar As Alterações Da Conta.')

    }

  }

  function abrirConta() {

    setNovoEmail(usuario.email || '')

    setNovaSenha('')

    setConfirmacaoSenha('')

    setErroConta('')

    setContaAberta(true)

  }

  function cancelarConta() {

    setErroConta('')

    setContaAberta(false)

    setNovaSenha('')

    setConfirmacaoSenha('')

  }

  return (

    <MenuPrincipal

      usuarioAtual={usuario}

      ativo="minhas-demandas"

      subtitulo="Minhas Demandas"

      onDashboard={onDashboard}

      onMinhasDemandas={() => {

        setContaAberta(false)

      }}

      onConfiguracoes={onConfiguracoes}

      onMinhaConta={() => {

        if (onConfiguracoes) {

          onConfiguracoes()

          return

        }

        abrirConta()

      }}

      onSair={onVoltar}

    >

      <div className="minhas-demandas-page">

        <div className="minhas-demandas-heading">

          <div>

            <h2>Minhas Demandas</h2>

            <p>Demandas Atualmente Atribuídas A <strong>{usuario.nome}</strong>.</p>

          </div>

        </div>

        <div className="md-summary">

          <span>

            <strong>{indicadores.total}</strong>{' '}

            {indicadores.total === 1 ? 'Demanda Atribuída' : 'Demandas Atribuídas'}

          </span>

          <span className={`md-summary-alert ${indicadores.atrasadas > 0 ? 'is-danger' : ''}`}>

            <strong>{indicadores.atrasadas}</strong>{' '}

            {indicadores.atrasadas === 1 ? 'Demanda Atrasada' : 'Demandas Atrasadas'}

          </span>

        </div>

        <section className="md-indicators" aria-label="Resumo Das Minhas Demandas">

          <button

            type="button"

            className={`md-indicator ${statusFiltro === 'Em Atendimento' ? 'is-active' : ''}`}

            onClick={() => setStatusFiltro(statusFiltro === 'Em Atendimento' ? 'Todos' : 'Em Atendimento')}

            aria-pressed={statusFiltro === 'Em Atendimento'}

          >

            <span>Em Atendimento</span>

            <strong>{indicadores.atendimento}</strong>

            <small>Ver Demandas</small>

          </button>

          <button

            type="button"

            className={`md-indicator md-indicator-warning ${statusFiltro === 'Com Pendências' ? 'is-active' : ''}`}

            onClick={() => setStatusFiltro(statusFiltro === 'Com Pendências' ? 'Todos' : 'Com Pendências')}

            aria-pressed={statusFiltro === 'Com Pendências'}

          >

            <span>Com Pendências</span>

            <strong>{indicadores.pendencias}</strong>

            <small>Ver Pendências</small>

          </button>

          <button

            type="button"

            className={`md-indicator md-indicator-muted ${statusFiltro === 'Aguardando' ? 'is-active' : ''}`}

            onClick={() => setStatusFiltro(statusFiltro === 'Aguardando' ? 'Todos' : 'Aguardando')}

            aria-pressed={statusFiltro === 'Aguardando'}

          >

            <span>Aguardando</span>

            <strong>{indicadores.aguardando}</strong>

            <small>Ver Aguardando</small>

          </button>

          <button

            type="button"

            className={`md-indicator md-indicator-success ${statusFiltro === 'Concluída' ? 'is-active' : ''}`}

            onClick={() => setStatusFiltro(statusFiltro === 'Concluída' ? 'Todos' : 'Concluída')}

            aria-pressed={statusFiltro === 'Concluída'}

          >

            <span>Concluídas</span>

            <strong>{indicadores.concluidas}</strong>

            <small>Ver Concluídas</small>

          </button>

        </section>

        <section className="md-filter-card">

          <div className="md-filter-heading">

            <div>

              <h3>Filtros</h3>

              <span>Use Os Filtros Para Encontrar Rapidamente Uma Demanda.</span>

            </div>

          </div>

          <div className="md-filter-search">

            <label htmlFor="md-pesquisa">Pesquisar</label>

            <input

              id="md-pesquisa"

              value={pesquisa}

              onChange={(event) => setPesquisa(event.target.value)}

              placeholder="Pesquisar Por ID, Título, Órgão, Sistema Ou Descrição..."

            />

          </div>

          <div className="md-filter-field">

            <label htmlFor="md-status">Status</label>

            <select id="md-status" value={statusFiltro} onChange={(event) => setStatusFiltro(event.target.value)}>

              {STATUS.map((status) => <option key={status} value={status}>{status}</option>)}

            </select>

          </div>

          <div className="md-filter-field">

            <label htmlFor="md-prioridade">Criticidade</label>

            <select id="md-prioridade" value={prioridadeFiltro} onChange={(event) => setPrioridadeFiltro(event.target.value)}>

              <option value="Todas">Selecione...</option>

              {PRIORIDADES.filter((prioridade) => prioridade !== "Todas").map((prioridade) => <option key={prioridade} value={prioridade}>{prioridade}</option>)}

            </select>

          </div>

          <div className="md-filter-field">
            <label htmlFor="md-prioridade-atendimento">Prioridade de Atendimento</label>
            <select id="md-prioridade-atendimento" value={prioridadeAtendimentoFiltro} onChange={(event) => setPrioridadeAtendimentoFiltro(event.target.value)}>
              {PRIORIDADES_ATENDIMENTO.map((prioridade) => <option key={prioridade} value={prioridade}>{prioridade}</option>)}
            </select>
          </div>

          <div className="md-filter-field">

            <label htmlFor="md-situacao">Situação</label>

            <select id="md-situacao" value={situacaoFiltro} onChange={(event) => setSituacaoFiltro(event.target.value)}>

              <option value="Todos">Todas</option>

              <option value="Abertas">Abertas</option>

              <option value="Concluídas">Concluídas</option>

              <option value="Atrasadas">Atrasadas</option>

            </select>

          </div>

          <button type="button" className="md-clear-button btn-secundario" onClick={limparFiltros}>Limpar Filtros</button>

        </section>

        <section className="md-table-card">

          <div className="md-table-header">

            <div>

              <h3>Minhas Demandas</h3>

              <p>

                {demandasFiltradas.length}{' '}

                {demandasFiltradas.length === 1 ? 'Registro Encontrado' : 'Registros Encontrados'}

              </p>

            </div>

            <span className="md-table-count">

              {demandasFiltradas.length === 1 ? '1 Demanda' : `${demandasFiltradas.length} Demandas`}

            </span>

          </div>

          {demandasFiltradas.length === 0 ? (

            <div className="md-empty">

              <div className="md-empty-icon">📋</div>

              <h3>Nenhuma Demanda Encontrada</h3>

              <p>Não Há Demandas Atribuídas A Você Com Os Filtros Selecionados.</p>

            </div>

          ) : (

            <div className="md-table-wrap">

              <table className="md-table">

                <thead>

                  <tr>

                    <th>ID</th>

                    <th>Demanda</th>

                    <th>Órgão</th>

                    <th>Classificação</th>

                    <th>Status</th>

                    <th>Prazo</th>

                    <th>SLA</th>

                    <th>Ações</th>

                  </tr>

                </thead>

                <tbody>

                  {demandasFiltradas.map((demanda) => {

                    const atrasada = estaAtrasada(demanda)

                    const proxima = estaProxima(demanda)

                    return (

                      <tr

                        key={demanda.id}

                        className={classeLinhaCriticidade(demanda.criticidade || demanda.prioridade)}

                      >

                        <td className="md-id">DEM-{String(demanda.id).padStart(5, '0')}</td>

                        <td>

                          <strong>{demanda.titulo}</strong>

                          <small>{demanda.sistema || '—'}</small>

                        </td>

                        <td>{demanda.cliente || '—'}</td>

                        <td>

                          <div className="md-classificacao-cell">

                            <span className={`md-priority ${classeCriticidade(demanda.criticidade || demanda.prioridade)}`}>

                              {demanda.criticidade || demanda.prioridade}

                            </span>

                            <small className={classePrioridadeAtendimento(demanda.prioridadeAtendimento || '')}>

                              {demanda.prioridadeAtendimento || '—'}

                            </small>

                          </div>

                        </td>

                        <td><span className={`md-status ${classeStatus(demanda.status)}`}>{demanda.status}</span></td>

                        <td>{formatarData(demanda.prazo)}</td>

                        <td>

                          <span className={`md-sla ${atrasada ? 'danger' : proxima ? 'warning' : 'ok'}`}>

                            {atrasada ? 'Atrasada' : proxima ? 'Próxima' : 'No Prazo'}

                          </span>

                        </td>

                        <td>

                          <div className="md-actions">

                            <button type="button" onClick={() => onAbrirDetalhe(demanda)}>Detalhes</button>

                            {demanda.status === 'Aguardando' && (

                              <button

                                type="button"

                                className="md-action-primary"

                                onClick={() => onAlterarStatus(demanda.id, 'Em Atendimento')}

                              >

                                Atender

                              </button>

                            )}

                            {demanda.status !== 'Concluída' && demanda.status !== 'Cancelada' && (

                              <>

                                <button type="button" className="md-action-warning" onClick={() => {

                                  const motivo = window.prompt('Informe O Motivo Da Pendência:')

                                  if (motivo?.trim()) onAlterarStatus(demanda.id, 'Com Pendências', motivo)

                                }}>Pendência</button>

                                <button type="button" className="md-action-success" onClick={() => {

                                  const comentario = window.prompt('Informe O Comentário De Conclusão:')

                                  if (comentario?.trim()) onAlterarStatus(demanda.id, 'Concluída', comentario)

                                }}>Concluir</button>

                              </>

                            )}

                          </div>

                        </td>

                      </tr>

                    )

                  })}

                </tbody>

              </table>

            </div>

          )}

        </section>

      </div>

      {contaAberta && (

        <div className="md-modal-backdrop" role="presentation">

          <div className="md-modal" role="dialog" aria-modal="true" aria-labelledby="md-conta-title">

            <div className="md-modal-header">

              <div>

                <h3 id="md-conta-title">Minha Conta</h3>

                <p>Altere seu e-mail e sua senha quando desejar.</p>

              </div>

              <button type="button" className="md-modal-close" onClick={cancelarConta} aria-label="Fechar">×</button>

            </div>

            <form onSubmit={salvarConta}>

              <div className="md-account-grid">

                <label>

                  Nome

                  <input value={usuario.nome} readOnly />

                </label>

                <label>

                  Login

                  <input value={usuario.login} readOnly />

                </label>

                <label className="md-account-full">

                  E-mail

                  <input type="email" value={novoEmail} onChange={(event) => setNovoEmail(event.target.value)} autoComplete="email" />

                </label>

                <label>

                  Nova Senha

                  <div className="md-password-wrap">

                    <input

                      type={mostrarNovaSenha ? 'text' : 'password'}

                      value={novaSenha}

                      onChange={(event) => setNovaSenha(event.target.value)}

                      minLength={MINIMO_SENHA}

                      placeholder={`Mínimo ${MINIMO_SENHA} Caracteres`}

                      autoComplete="new-password"

                    />

                    <button type="button" onClick={() => setMostrarNovaSenha((valor) => !valor)} aria-label={mostrarNovaSenha ? 'Ocultar Senha' : 'Visualizar Senha'}>🔍</button>

                  </div>

                </label>

                <label>

                  Confirmar Senha

                  <div className="md-password-wrap">

                    <input

                      type={mostrarConfirmacao ? 'text' : 'password'}

                      value={confirmacaoSenha}

                      onChange={(event) => setConfirmacaoSenha(event.target.value)}

                      minLength={MINIMO_SENHA}

                      placeholder="Repita A Senha"

                      autoComplete="new-password"

                    />

                    <button type="button" onClick={() => setMostrarConfirmacao((valor) => !valor)} aria-label={mostrarConfirmacao ? 'Ocultar Senha' : 'Visualizar Senha'}>🔍</button>

                  </div>

                </label>

              </div>

              <div className="md-account-note">A Alteração De Senha Exige No Mínimo 6 Caracteres. Deixe Os Campos De Senha Vazios Para Manter A Senha Atual.</div>

              {erroConta && <div className="md-account-error">{erroConta}</div>}

              <div className="md-modal-actions">

                <button type="button" className="md-cancel-button btn-secundario" onClick={cancelarConta}>Cancelar</button>

                <button type="submit" className="md-save-button btn-principal">Salvar Alterações</button>

              </div>

            </form>

          </div>

        </div>

      )}

    </MenuPrincipal>

  )

}
